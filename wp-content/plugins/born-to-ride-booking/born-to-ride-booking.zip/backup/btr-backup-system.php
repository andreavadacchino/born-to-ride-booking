<?php
/**
 * Sistema di Backup Completo Born to Ride
 * 
 * ATTENZIONE: Eseguire SEMPRE prima di qualsiasi modifica
 * 
 * @package BTR
 * @version 1.0.0
 * @since 1.0.236
 */

if (!defined('ABSPATH')) {
    // Permetti esecuzione diretta per CLI
    require_once(dirname(__FILE__) . '/../../../../wp-load.php');
}

class BTR_Backup_System {
    
    private $backup_dir;
    private $backup_id;
    private $manifest = [];
    private $errors = [];
    private $log_file;
    
    public function __construct() {
        $this->backup_id = 'btr_backup_' . date('Y-m-d_H-i-s');
        $this->backup_dir = WP_CONTENT_DIR . '/btr-backups/' . $this->backup_id;
        $this->log_file = $this->backup_dir . '/backup.log';
        
        // Crea directory backup
        if (!file_exists(dirname($this->backup_dir))) {
            wp_mkdir_p(dirname($this->backup_dir));
        }
        wp_mkdir_p($this->backup_dir);
        
        $this->log("=== INIZIO BACKUP BTR: {$this->backup_id} ===");
    }
    
    /**
     * Esegue backup completo
     */
    public function execute_full_backup() {
        $this->log("Avvio backup completo del sistema Born to Ride...");
        
        $steps = [
            'backup_database_tables' => 'Backup tabelle database',
            'backup_postmeta_data' => 'Backup dati postmeta',
            'backup_options' => 'Backup configurazioni',
            'backup_plugin_files' => 'Backup file plugin',
            'backup_uploads' => 'Backup file caricati',
            'create_manifest' => 'Creazione manifest',
            'verify_backup' => 'Verifica integrità'
        ];
        
        $success = true;
        
        foreach ($steps as $method => $description) {
            $this->log("\n▶ {$description}...");
            
            try {
                if (method_exists($this, $method)) {
                    $result = $this->$method();
                    if ($result) {
                        $this->log("  ✅ {$description} completato");
                    } else {
                        $this->log("  ❌ ERRORE in {$description}");
                        $success = false;
                    }
                }
            } catch (Exception $e) {
                $this->log("  ❌ ECCEZIONE: " . $e->getMessage());
                $this->errors[] = $e->getMessage();
                $success = false;
            }
        }
        
        if ($success) {
            $this->log("\n✅ BACKUP COMPLETATO CON SUCCESSO!");
            $this->log("📁 Directory backup: {$this->backup_dir}");
            $this->create_restore_script();
        } else {
            $this->log("\n❌ BACKUP COMPLETATO CON ERRORI");
            $this->log("Errori riscontrati: " . implode(', ', $this->errors));
        }
        
        return $success;
    }
    
    /**
     * Backup tabelle database BTR
     */
    private function backup_database_tables() {
        global $wpdb;
        
        $tables = [
            $wpdb->prefix . 'btr_group_payments',
            $wpdb->prefix . 'btr_payment_plans',
            $wpdb->prefix . 'btr_order_shares',
            $wpdb->prefix . 'btr_email_templates',
            $wpdb->prefix . 'btr_payment_reminders'
        ];
        
        foreach ($tables as $table) {
            // Verifica esistenza tabella
            $exists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'");
            if (!$exists) {
                $this->log("  ⚠️  Tabella {$table} non trovata, skip");
                continue;
            }
            
            // Esporta struttura
            $create_table = $wpdb->get_row("SHOW CREATE TABLE {$table}", ARRAY_N);
            if ($create_table) {
                $sql_file = $this->backup_dir . '/db/' . basename($table) . '.sql';
                wp_mkdir_p(dirname($sql_file));
                
                file_put_contents($sql_file, "-- Struttura tabella {$table}\n");
                file_put_contents($sql_file, "DROP TABLE IF EXISTS {$table};\n", FILE_APPEND);
                file_put_contents($sql_file, $create_table[1] . ";\n\n", FILE_APPEND);
                
                // Esporta dati
                $rows = $wpdb->get_results("SELECT * FROM {$table}", ARRAY_A);
                if ($rows) {
                    file_put_contents($sql_file, "-- Dati tabella {$table}\n", FILE_APPEND);
                    foreach ($rows as $row) {
                        $columns = array_keys($row);
                        $values = array_values($row);
                        
                        // Escape valori
                        $escaped_values = array_map(function($val) use ($wpdb) {
                            if ($val === null) {
                                return 'NULL';
                            }
                            return "'" . $wpdb->_real_escape($val) . "'";
                        }, $values);
                        
                        $insert = "INSERT INTO {$table} (" . implode(',', $columns) . ") VALUES (" . implode(',', $escaped_values) . ");\n";
                        file_put_contents($sql_file, $insert, FILE_APPEND);
                    }
                    $this->log("  📊 Esportate " . count($rows) . " righe da {$table}");
                }
                
                $this->manifest['database'][] = basename($table);
            }
        }
        
        return true;
    }
    
    /**
     * Backup dati postmeta relativi a BTR
     */
    private function backup_postmeta_data() {
        global $wpdb;
        
        // Query per trovare tutti i preventivi
        $preventivi_ids = $wpdb->get_col("
            SELECT DISTINCT ID 
            FROM {$wpdb->posts} 
            WHERE post_type IN ('btr_preventivi', 'btr_pacchetti', 'btr_prenotazioni')
        ");
        
        if (empty($preventivi_ids)) {
            $this->log("  ⚠️  Nessun preventivo trovato");
            return true;
        }
        
        $this->log("  📋 Trovati " . count($preventivi_ids) . " preventivi/pacchetti");
        
        // Esporta postmeta
        $meta_file = $this->backup_dir . '/db/postmeta_btr.sql';
        wp_mkdir_p(dirname($meta_file));
        
        file_put_contents($meta_file, "-- Backup postmeta BTR\n");
        file_put_contents($meta_file, "-- Data: " . date('Y-m-d H:i:s') . "\n\n");
        
        foreach (array_chunk($preventivi_ids, 100) as $chunk) {
            $ids = implode(',', $chunk);
            $metas = $wpdb->get_results("
                SELECT post_id, meta_key, meta_value 
                FROM {$wpdb->postmeta} 
                WHERE post_id IN ({$ids})
            ", ARRAY_A);
            
            foreach ($metas as $meta) {
                $insert = $wpdb->prepare(
                    "INSERT INTO {$wpdb->postmeta} (post_id, meta_key, meta_value) VALUES (%d, %s, %s) ON DUPLICATE KEY UPDATE meta_value = VALUES(meta_value);\n",
                    $meta['post_id'],
                    $meta['meta_key'],
                    $meta['meta_value']
                );
                file_put_contents($meta_file, $insert, FILE_APPEND);
            }
        }
        
        $this->manifest['postmeta'] = 'postmeta_btr.sql';
        return true;
    }
    
    /**
     * Backup opzioni e configurazioni
     */
    private function backup_options() {
        global $wpdb;
        
        $option_patterns = [
            'btr_%',
            'born_to_ride_%',
            'woocommerce_btr_%'
        ];
        
        $options_file = $this->backup_dir . '/db/options_btr.sql';
        wp_mkdir_p(dirname($options_file));
        
        file_put_contents($options_file, "-- Backup opzioni BTR\n\n");
        
        foreach ($option_patterns as $pattern) {
            $options = $wpdb->get_results($wpdb->prepare(
                "SELECT option_name, option_value, autoload 
                 FROM {$wpdb->options} 
                 WHERE option_name LIKE %s",
                $pattern
            ), ARRAY_A);
            
            foreach ($options as $option) {
                $insert = $wpdb->prepare(
                    "INSERT INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, %s) ON DUPLICATE KEY UPDATE option_value = VALUES(option_value);\n",
                    $option['option_name'],
                    $option['option_value'],
                    $option['autoload']
                );
                file_put_contents($options_file, $insert, FILE_APPEND);
            }
            
            $this->log("  ⚙️  Salvate " . count($options) . " opzioni per pattern: {$pattern}");
        }
        
        $this->manifest['options'] = 'options_btr.sql';
        return true;
    }
    
    /**
     * Backup file del plugin
     */
    private function backup_plugin_files() {
        $plugin_dir = WP_PLUGIN_DIR . '/born-to-ride-booking';
        $backup_files_dir = $this->backup_dir . '/files/plugin';
        
        if (!is_dir($plugin_dir)) {
            $this->log("  ❌ Directory plugin non trovata: {$plugin_dir}");
            return false;
        }
        
        // Crea archivio ZIP
        $zip_file = $this->backup_dir . '/plugin_files.zip';
        $zip = new ZipArchive();
        
        if ($zip->open($zip_file, ZipArchive::CREATE) !== TRUE) {
            $this->log("  ❌ Impossibile creare ZIP");
            return false;
        }
        
        $this->add_files_to_zip($zip, $plugin_dir, '');
        $zip->close();
        
        $size = filesize($zip_file);
        $this->log("  📦 Creato archivio plugin: " . $this->format_bytes($size));
        $this->manifest['plugin_files'] = 'plugin_files.zip';
        
        return true;
    }
    
    /**
     * Backup file caricati relativi a BTR
     */
    private function backup_uploads() {
        $uploads_dir = wp_upload_dir();
        $btr_uploads = $uploads_dir['basedir'] . '/btr';
        
        if (!is_dir($btr_uploads)) {
            $this->log("  ℹ️  Nessuna directory uploads BTR");
            return true;
        }
        
        $zip_file = $this->backup_dir . '/uploads_btr.zip';
        $zip = new ZipArchive();
        
        if ($zip->open($zip_file, ZipArchive::CREATE) !== TRUE) {
            return false;
        }
        
        $this->add_files_to_zip($zip, $btr_uploads, '');
        $zip->close();
        
        $this->log("  📸 Backup uploads completato");
        $this->manifest['uploads'] = 'uploads_btr.zip';
        
        return true;
    }
    
    /**
     * Crea manifest del backup
     */
    private function create_manifest() {
        $this->manifest['backup_info'] = [
            'id' => $this->backup_id,
            'date' => date('Y-m-d H:i:s'),
            'wp_version' => get_bloginfo('version'),
            'php_version' => PHP_VERSION,
            'plugin_version' => defined('BTR_VERSION') ? BTR_VERSION : 'unknown',
            'site_url' => get_site_url(),
            'db_prefix' => $GLOBALS['wpdb']->prefix
        ];
        
        $manifest_file = $this->backup_dir . '/manifest.json';
        file_put_contents($manifest_file, json_encode($this->manifest, JSON_PRETTY_PRINT));
        
        $this->log("  📄 Manifest creato: manifest.json");
        return true;
    }
    
    /**
     * Verifica integrità backup
     */
    private function verify_backup() {
        $required_files = [
            '/manifest.json',
            '/backup.log'
        ];
        
        foreach ($required_files as $file) {
            if (!file_exists($this->backup_dir . $file)) {
                $this->log("  ❌ File mancante: {$file}");
                return false;
            }
        }
        
        // Calcola checksum
        $checksum = $this->calculate_backup_checksum();
        file_put_contents($this->backup_dir . '/checksum.txt', $checksum);
        
        $this->log("  🔐 Checksum: {$checksum}");
        return true;
    }
    
    /**
     * Crea script di ripristino
     */
    private function create_restore_script() {
        $restore_script = $this->backup_dir . '/restore.php';
        
        $script_content = '<?php
/**
 * Script di Ripristino BTR
 * Backup ID: ' . $this->backup_id . '
 * 
 * ATTENZIONE: Questo script ripristinerà TUTTI i dati al momento del backup
 * 
 * Uso: php restore.php [--confirm]
 */

if (PHP_SAPI !== "cli") {
    die("Questo script può essere eseguito solo da CLI\n");
}

if (!isset($argv[1]) || $argv[1] !== "--confirm") {
    echo "\n⚠️  ATTENZIONE: Questo ripristinerà TUTTI i dati BTR!\n";
    echo "Per confermare, esegui: php restore.php --confirm\n\n";
    exit(1);
}

require_once(dirname(__FILE__) . "/../../../../../wp-load.php");

class BTR_Restore {
    
    private $backup_dir;
    private $manifest;
    
    public function __construct($backup_dir) {
        $this->backup_dir = $backup_dir;
        $this->load_manifest();
    }
    
    private function load_manifest() {
        $manifest_file = $this->backup_dir . "/manifest.json";
        if (!file_exists($manifest_file)) {
            die("❌ Manifest non trovato!\n");
        }
        $this->manifest = json_decode(file_get_contents($manifest_file), true);
    }
    
    public function restore() {
        global $wpdb;
        
        echo "\n🔄 AVVIO RIPRISTINO...\n";
        echo "📅 Backup del: " . $this->manifest["backup_info"]["date"] . "\n\n";
        
        // 1. Ripristina database
        if (isset($this->manifest["database"])) {
            echo "▶ Ripristino tabelle database...\n";
            foreach ($this->manifest["database"] as $table) {
                $sql_file = $this->backup_dir . "/db/" . $table . ".sql";
                if (file_exists($sql_file)) {
                    $sql = file_get_contents($sql_file);
                    $queries = explode(";\n", $sql);
                    foreach ($queries as $query) {
                        if (trim($query)) {
                            $wpdb->query($query);
                        }
                    }
                    echo "  ✅ Ripristinata tabella: {$table}\n";
                }
            }
        }
        
        // 2. Ripristina postmeta
        if (isset($this->manifest["postmeta"])) {
            echo "\n▶ Ripristino postmeta...\n";
            $meta_file = $this->backup_dir . "/db/" . $this->manifest["postmeta"];
            if (file_exists($meta_file)) {
                $sql = file_get_contents($meta_file);
                $queries = explode(";\n", $sql);
                $count = 0;
                foreach ($queries as $query) {
                    if (trim($query)) {
                        $wpdb->query($query);
                        $count++;
                    }
                }
                echo "  ✅ Ripristinati {$count} metadati\n";
            }
        }
        
        // 3. Ripristina opzioni
        if (isset($this->manifest["options"])) {
            echo "\n▶ Ripristino opzioni...\n";
            $options_file = $this->backup_dir . "/db/" . $this->manifest["options"];
            if (file_exists($options_file)) {
                $sql = file_get_contents($sql_file);
                $queries = explode(";\n", $sql);
                foreach ($queries as $query) {
                    if (trim($query)) {
                        $wpdb->query($query);
                    }
                }
                echo "  ✅ Opzioni ripristinate\n";
            }
        }
        
        // 4. Ripristina file plugin
        if (isset($this->manifest["plugin_files"])) {
            echo "\n▶ Ripristino file plugin...\n";
            $zip_file = $this->backup_dir . "/" . $this->manifest["plugin_files"];
            if (file_exists($zip_file)) {
                $plugin_dir = WP_PLUGIN_DIR . "/born-to-ride-booking";
                
                // Backup directory corrente
                if (is_dir($plugin_dir)) {
                    rename($plugin_dir, $plugin_dir . "_old_" . time());
                }
                
                $zip = new ZipArchive();
                if ($zip->open($zip_file) === TRUE) {
                    $zip->extractTo($plugin_dir);
                    $zip->close();
                    echo "  ✅ File plugin ripristinati\n";
                }
            }
        }
        
        // 5. Pulisci cache
        wp_cache_flush();
        
        echo "\n✅ RIPRISTINO COMPLETATO!\n";
        echo "⚠️  Ricorda di:\n";
        echo "  1. Verificare il funzionamento del sito\n";
        echo "  2. Testare le funzionalità critiche\n";
        echo "  3. Controllare i log per errori\n\n";
    }
}

$restore = new BTR_Restore(dirname(__FILE__));
$restore->restore();
';
        
        file_put_contents($restore_script, $script_content);
        chmod($restore_script, 0755);
        
        $this->log("\n  💾 Script di ripristino creato: restore.php");
    }
    
    /**
     * Helper: Aggiunge file a ZIP ricorsivamente
     */
    private function add_files_to_zip($zip, $dir, $base) {
        $files = scandir($dir);
        
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') continue;
            
            $path = $dir . '/' . $file;
            $zip_path = $base ? $base . '/' . $file : $file;
            
            if (is_dir($path)) {
                $zip->addEmptyDir($zip_path);
                $this->add_files_to_zip($zip, $path, $zip_path);
            } else {
                $zip->addFile($path, $zip_path);
            }
        }
    }
    
    /**
     * Calcola checksum del backup
     */
    private function calculate_backup_checksum() {
        $files = glob($this->backup_dir . '/*');
        $hashes = [];
        
        foreach ($files as $file) {
            if (is_file($file) && basename($file) !== 'checksum.txt') {
                $hashes[] = md5_file($file);
            }
        }
        
        return md5(implode('', $hashes));
    }
    
    /**
     * Formatta bytes in formato leggibile
     */
    private function format_bytes($bytes, $precision = 2) {
        $units = ['B', 'KB', 'MB', 'GB'];
        
        for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
            $bytes /= 1024;
        }
        
        return round($bytes, $precision) . ' ' . $units[$i];
    }
    
    /**
     * Log con timestamp
     */
    private function log($message) {
        $timestamp = date('Y-m-d H:i:s');
        $log_message = "[{$timestamp}] {$message}\n";
        
        echo $log_message;
        
        if ($this->log_file) {
            file_put_contents($this->log_file, $log_message, FILE_APPEND);
        }
    }
}

// Esecuzione
if (PHP_SAPI === 'cli' || (defined('DOING_CRON') && DOING_CRON)) {
    $backup = new BTR_Backup_System();
    $result = $backup->execute_full_backup();
    exit($result ? 0 : 1);
} else {
    // Interfaccia web (solo per admin)
    if (!current_user_can('manage_options')) {
        wp_die('Accesso negato');
    }
    
    echo '<h1>Sistema Backup BTR</h1>';
    echo '<p>Per eseguire il backup, usa WP-CLI:</p>';
    echo '<code>wp eval-file ' . __FILE__ . '</code>';
}