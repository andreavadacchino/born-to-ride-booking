<?php
/**
 * Analizza il bug nel calcolo prezzi
 */

// Load WordPress
$wp_load = false;
$paths_to_check = [
    '../../../../wp-load.php',
    dirname(__FILE__) . '/../../../../wp-load.php',
];

foreach ($paths_to_check as $path) {
    if (file_exists($path)) {
        $wp_load = $path;
        break;
    }
}

if ($wp_load) {
    require_once($wp_load);
} else {
    die('Errore: Impossibile trovare wp-load.php');
}

// Verifica permessi
if (!current_user_can('manage_options')) {
    wp_die('Accesso negato');
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Analisi Bug Calcolo Prezzi</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 1000px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        h1 { color: #333; border-bottom: 3px solid #0097c5; padding-bottom: 15px; }
        .analysis { margin: 20px 0; padding: 20px; background: #f8f9fa; border-radius: 5px; }
        .code-block { background: #263238; color: #aed581; padding: 15px; border-radius: 5px; font-family: 'Courier New', monospace; overflow-x: auto; margin: 10px 0; }
        .highlight { background: #ffeb3b; color: #000; padding: 2px 4px; }
        .error { background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .success { background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .warning { background: #fff3cd; color: #856404; padding: 15px; border-radius: 5px; margin: 10px 0; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        th, td { padding: 8px; text-align: left; border: 1px solid #ddd; }
        th { background: #f0f0f0; }
        .comparison { display: flex; gap: 20px; }
        .comparison > div { flex: 1; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🐛 Analisi Bug Calcolo Prezzi - Differenza €40</h1>
        
        <div class="analysis">
            <h2>🔍 Problema Identificato</h2>
            <div class="error">
                <p><strong>Bug trovato:</strong> Il supplemento base di €10 viene calcolato solo per 1 notte invece che per le notti del pacchetto base.</p>
                <p>Questo spiega esattamente la differenza di €40:</p>
                <ul>
                    <li>2 adulti × €10 supplemento × 2 notti (pacchetto base) = €40</li>
                    <li>Ma il sistema calcola: 2 adulti × €10 × 1 notte = €20</li>
                    <li>Differenza: €40 - €20 = €20 per adulti</li>
                    <li>Stesso errore per i bambini: totale differenza = €40</li>
                </ul>
            </div>
        </div>

        <div class="analysis">
            <h2>📝 Codice Attuale (ERRATO)</h2>
            <div class="code-block">
// Linea 3007 in frontend-scripts.js
subtotale_supplemento_base: numAdults * supplementoPP,  // ❌ Manca moltiplicazione per notti

// Dovrebbe essere:
subtotale_supplemento_base: numAdults * supplementoPP * packageNights,  // ✅
            </div>
        </div>

        <div class="analysis">
            <h2>📊 Confronto Calcoli</h2>
            <div class="comparison">
                <div>
                    <h3>❌ Calcolo Attuale (ERRATO)</h3>
                    <table>
                        <tr>
                            <th>Voce</th>
                            <th>Calcolo</th>
                            <th>Importo</th>
                        </tr>
                        <tr>
                            <td>2 Adulti base</td>
                            <td>2 × €159</td>
                            <td>€318,00</td>
                        </tr>
                        <tr class="highlight">
                            <td>Supplemento base adulti</td>
                            <td>2 × €10 × <strong>1</strong></td>
                            <td>€20,00</td>
                        </tr>
                        <tr>
                            <td>Notti extra adulti</td>
                            <td>2 × €40</td>
                            <td>€80,00</td>
                        </tr>
                        <tr>
                            <td>Supplemento extra adulti</td>
                            <td>2 × €10</td>
                            <td>€20,00</td>
                        </tr>
                        <tr>
                            <td colspan="2"><strong>Subtotale Adulti</strong></td>
                            <td><strong>€438,00</strong></td>
                        </tr>
                    </table>
                    
                    <p>Ma il sistema mostra €458,00 per gli adulti (+€20)</p>
                </div>
                
                <div>
                    <h3>✅ Calcolo Corretto</h3>
                    <table>
                        <tr>
                            <th>Voce</th>
                            <th>Calcolo</th>
                            <th>Importo</th>
                        </tr>
                        <tr>
                            <td>2 Adulti base</td>
                            <td>2 × €159</td>
                            <td>€318,00</td>
                        </tr>
                        <tr class="highlight">
                            <td>Supplemento base adulti</td>
                            <td>2 × €10 × <strong>1</strong></td>
                            <td>€20,00</td>
                        </tr>
                        <tr>
                            <td>Notti extra adulti</td>
                            <td>2 × €40</td>
                            <td>€80,00</td>
                        </tr>
                        <tr>
                            <td>Supplemento extra adulti</td>
                            <td>2 × €10</td>
                            <td>€20,00</td>
                        </tr>
                        <tr>
                            <td colspan="2"><strong>Subtotale Adulti</strong></td>
                            <td><strong>€438,00</strong></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

        <div class="analysis">
            <h2>🤔 Analisi Approfondita</h2>
            <div class="warning">
                <p><strong>Domanda importante:</strong> Il supplemento base di €10 deve essere moltiplicato per le notti del pacchetto base?</p>
                <p>Se il pacchetto base include 1 notte e c'è 1 notte extra:</p>
                <ul>
                    <li><strong>Scenario A:</strong> Supplemento base solo per 1 notte (come ora) = €10</li>
                    <li><strong>Scenario B:</strong> Supplemento base per tutte le notti del pacchetto = €10 × notti_pacchetto</li>
                </ul>
                <p>La differenza di €40 suggerisce che il sistema sta applicando uno scenario misto non corretto.</p>
            </div>
        </div>

        <div class="analysis">
            <h2>🔧 Verifica nel Frontend</h2>
            <p>Apri la console JavaScript e esegui questo codice per verificare:</p>
            <div class="code-block">
// Verifica come viene calcolato il supplemento
console.log('=== VERIFICA CALCOLO SUPPLEMENTI ===');

// Trova il riepilogo dinamico
var summaryText = jQuery('.btr-dynamic-summary').text();
console.log('Riepilogo:', summaryText);

// Estrai il totale mostrato
var totalMatch = summaryText.match(/€([\d,\.]+)/g);
if (totalMatch) {
    console.log('Totale trovato:', totalMatch[totalMatch.length - 1]);
}

// Verifica i dati del pacchetto
console.log('Notti pacchetto base:', window.btrPackageData?.nights || 'Non definito');
console.log('Notti extra configurate:', window.btrExtraNightsCount || 'Non definito');
            </div>
        </div>

        <div class="analysis">
            <h2>💡 Soluzione Proposta</h2>
            <div class="success">
                <p>Per risolvere il problema, dobbiamo chiarire la logica business:</p>
                <ol>
                    <li>Il supplemento di €10 è "a persona, a notte" per TUTTE le notti?</li>
                    <li>O è un supplemento fisso per il pacchetto base + supplemento per notti extra?</li>
                </ol>
                <p>Basandoci sul testo mostrato "supplemento €10,00 a persona, <strong>a notte</strong>", sembra che dovrebbe essere applicato per ogni notte.</p>
            </div>
        </div>
    </div>
</body>
</html>