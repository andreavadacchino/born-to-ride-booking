<?php
/**
 * Script per forzare la ricostruzione del pacchetto v1.0.30
 */

// Load WordPress
$wp_load = false;
$paths_to_check = [
    '../../../../wp-load.php',
    dirname(__FILE__) . '/../../../../wp-load.php',
];

foreach ($paths_to_check as $path) {
    if (file_exists($path)) {
        $wp_load = $path;
        break;
    }
}

if ($wp_load) {
    require_once($wp_load);
} else {
    die('Errore: Impossibile trovare wp-load.php');
}

// Verifica permessi
if (!current_user_can('manage_options')) {
    wp_die('Accesso negato');
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Force Rebuild v1.0.30</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        h1 { color: #333; border-bottom: 3px solid #0097c5; padding-bottom: 15px; }
        .result { padding: 20px; margin: 20px 0; border-radius: 5px; }
        .success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .info { background: #d1ecf1; color: #0c5460; border: 1px solid #bee5eb; }
        .code { background: #f8f9fa; padding: 10px; border-radius: 5px; font-family: monospace; margin: 10px 0; }
        .button { background: #0097c5; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; margin: 10px 0; }
        .button:hover { background: #007aa3; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔄 Force Rebuild Plugin v1.0.30</h1>
        
        <?php
        $plugin_dir = dirname(__FILE__);
        $build_dir = $plugin_dir . '/build';
        $old_zip = $build_dir . '/born-to-ride-booking-v1.0.30.zip';
        $plugin_name = 'born-to-ride-booking';
        $version = '1.0.30';
        
        // Cancella vecchio file se esiste
        if (file_exists($old_zip)) {
            unlink($old_zip);
            echo '<div class="info">🗑️ Vecchio file ZIP eliminato</div>';
        }
        
        // Crea directory build se non esiste
        if (!is_dir($build_dir)) {
            mkdir($build_dir, 0755, true);
        }
        
        // Prepara lista file da escludere
        $exclude_patterns = [
            '*.git*',
            '*.DS_Store',
            'build/*',
            'tests/*',
            'test-*.php',
            'debug-*.php',
            'force-rebuild-*.php',
            'build-release.php',
            'build-plugin-zip.php',
            '*.md',
            'node_modules/*',
            '.gitignore',
            '.editorconfig'
        ];
        
        // Crea comando ZIP
        $zip_file = $build_dir . '/' . $plugin_name . '-v' . $version . '.zip';
        $exclude_args = '';
        foreach ($exclude_patterns as $pattern) {
            $exclude_args .= ' -x "' . $pattern . '"';
        }
        
        // Esegui comando ZIP
        $command = 'cd ' . escapeshellarg($plugin_dir) . ' && zip -r ' . escapeshellarg($zip_file) . ' .' . $exclude_args . ' 2>&1';
        $output = shell_exec($command);
        
        if (file_exists($zip_file)) {
            $size = filesize($zip_file);
            $size_mb = round($size / 1024 / 1024, 2);
            ?>
            <div class="result success">
                <h2>✅ Build Completata!</h2>
                <p><strong>File creato:</strong> <?php echo basename($zip_file); ?></p>
                <p><strong>Dimensione:</strong> <?php echo $size_mb; ?> MB</p>
                <p><strong>Percorso:</strong></p>
                <div class="code"><?php echo $zip_file; ?></div>
                
                <a href="build/<?php echo basename($zip_file); ?>" download class="button">
                    📥 Scarica born-to-ride-booking-v1.0.30.zip
                </a>
            </div>
            
            <div class="info">
                <h3>📋 Modifiche incluse in v1.0.30:</h3>
                <ul>
                    <li>Sistema notti extra dinamico completo</li>
                    <li>Supporto date multiple (1, 2, 3... N notti)</li>
                    <li>Formattazione intelligente date: "21, 22, 23/01/2026"</li>
                    <li>Fix normalizzazione date Y-m-d</li>
                    <li>Fix caricamento dati AJAX</li>
                </ul>
            </div>
            
            <?php
        } else {
            ?>
            <div class="result error">
                <h2>❌ Errore nella creazione del file</h2>
                <p>Output del comando:</p>
                <div class="code"><?php echo htmlspecialchars($output); ?></div>
            </div>
            <?php
        }
        ?>
        
        <div class="info">
            <h3>🔍 Verifica contenuto ZIP:</h3>
            <p>Per verificare che il file contenga le ultime modifiche:</p>
            <div class="code">
unzip -l <?php echo $zip_file; ?> | grep -E "(class-btr-shortcodes|frontend-scripts)"
            </div>
        </div>
    </div>
</body>
</html>