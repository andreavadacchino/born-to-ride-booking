<?php
/**
 * Analisi problema prezzi in produzione
 */

// Load WordPress
$wp_load = false;
$paths_to_check = [
    '../../../../wp-load.php',
    dirname(__FILE__) . '/../../../../wp-load.php',
];

foreach ($paths_to_check as $path) {
    if (file_exists($path)) {
        $wp_load = $path;
        break;
    }
}

if ($wp_load) {
    require_once($wp_load);
} else {
    die('Errore: Impossibile trovare wp-load.php');
}

// Verifica permessi
if (!current_user_can('manage_options')) {
    wp_die('Accesso negato');
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Analisi Prezzi Produzione</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        h1 { color: #333; border-bottom: 3px solid #0097c5; padding-bottom: 15px; }
        .section { margin: 20px 0; padding: 20px; background: #f8f9fa; border-radius: 5px; }
        .error { background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .warning { background: #fff3cd; color: #856404; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .success { background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 10px 0; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        th, td { padding: 10px; text-align: left; border: 1px solid #ddd; }
        th { background: #f0f0f0; }
        .highlight { background: #ffeb3b; padding: 2px 4px; }
        .total-row { font-weight: bold; background: #e8f5e9; }
        .code { background: #263238; color: #aed581; padding: 15px; border-radius: 5px; font-family: monospace; overflow-x: auto; margin: 10px 0; }
        .comparison { display: flex; gap: 20px; margin: 20px 0; }
        .comparison > div { flex: 1; padding: 20px; background: #f8f9fa; border-radius: 5px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 Analisi Problema Prezzi in Produzione</h1>
        
        <div class="error">
            <h2>⚠️ Anomalie Rilevate</h2>
            <ul>
                <li>Prezzo notte extra adulti: <strong>€80</strong> invece di €40 (DOPPIO!)</li>
                <li>Prezzo bambino 3-8: <strong>€119,01</strong> invece di €111,30</li>
                <li>Prezzo bambino 8-12: <strong>€127,20</strong> invece di €119,25</li>
                <li>Totale: <strong>€874,21</strong> (sembra troppo alto)</li>
            </ul>
        </div>

        <div class="comparison">
            <div>
                <h3>🖥️ Produzione (ERRATO)</h3>
                <table>
                    <tr><th>Voce</th><th>Calcolo</th><th>Importo</th></tr>
                    <tr>
                        <td>2 Adulti base</td>
                        <td>2 × €159,00</td>
                        <td>€318,00</td>
                    </tr>
                    <tr>
                        <td>Supplemento base adulti</td>
                        <td>2 × €10,00</td>
                        <td>€20,00</td>
                    </tr>
                    <tr class="highlight">
                        <td>Notti extra adulti</td>
                        <td>2 × €80,00 ❌</td>
                        <td>€160,00</td>
                    </tr>
                    <tr>
                        <td>Supplemento extra adulti</td>
                        <td>2 × €10,00</td>
                        <td>€20,00</td>
                    </tr>
                    <tr class="total-row">
                        <td colspan="2">Subtotale Adulti</td>
                        <td>€518,00</td>
                    </tr>
                    
                    <tr>
                        <td>1 Bambino 3-8 base</td>
                        <td>1 × €119,01</td>
                        <td>€119,01</td>
                    </tr>
                    <tr>
                        <td>Supplemento base</td>
                        <td>1 × €10,00</td>
                        <td>€10,00</td>
                    </tr>
                    <tr>
                        <td>Notte extra</td>
                        <td>1 × €20,00</td>
                        <td>€20,00</td>
                    </tr>
                    <tr>
                        <td>Supplemento extra</td>
                        <td>1 × €10,00</td>
                        <td>€10,00</td>
                    </tr>
                    <tr class="total-row">
                        <td colspan="2">Subtotale Bambino 3-8</td>
                        <td>€159,01</td>
                    </tr>
                    
                    <tr>
                        <td>1 Bambino 8-12 base</td>
                        <td>1 × €127,20</td>
                        <td>€127,20</td>
                    </tr>
                    <tr>
                        <td>Supplemento base</td>
                        <td>1 × €10,00</td>
                        <td>€10,00</td>
                    </tr>
                    <tr>
                        <td>Notte extra</td>
                        <td>1 × €30,00</td>
                        <td>€30,00</td>
                    </tr>
                    <tr>
                        <td>Supplemento extra</td>
                        <td>1 × €10,00</td>
                        <td>€10,00</td>
                    </tr>
                    <tr class="total-row">
                        <td colspan="2">Subtotale Bambino 8-12</td>
                        <td>€177,20</td>
                    </tr>
                    
                    <tr class="total-row" style="font-size: 1.2em;">
                        <td colspan="2">TOTALE PRODUZIONE</td>
                        <td>€854,21</td>
                    </tr>
                </table>
            </div>
            
            <div>
                <h3>✅ Locale (CORRETTO)</h3>
                <table>
                    <tr><th>Voce</th><th>Calcolo</th><th>Importo</th></tr>
                    <tr>
                        <td>2 Adulti base</td>
                        <td>2 × €159,00</td>
                        <td>€318,00</td>
                    </tr>
                    <tr>
                        <td>Supplemento base adulti</td>
                        <td>2 × €10,00</td>
                        <td>€20,00</td>
                    </tr>
                    <tr class="highlight">
                        <td>Notti extra adulti</td>
                        <td>2 × €40,00 ✅</td>
                        <td>€80,00</td>
                    </tr>
                    <tr>
                        <td>Supplemento extra adulti</td>
                        <td>2 × €10,00</td>
                        <td>€20,00</td>
                    </tr>
                    <tr class="total-row">
                        <td colspan="2">Subtotale Adulti</td>
                        <td>€438,00</td>
                    </tr>
                    
                    <tr>
                        <td>1 Bambino 3-8 base</td>
                        <td>1 × €111,30</td>
                        <td>€111,30</td>
                    </tr>
                    <tr>
                        <td>Supplemento base</td>
                        <td>1 × €10,00</td>
                        <td>€10,00</td>
                    </tr>
                    <tr>
                        <td>Notte extra</td>
                        <td>1 × €15,00</td>
                        <td>€15,00</td>
                    </tr>
                    <tr>
                        <td>Supplemento extra</td>
                        <td>1 × €10,00</td>
                        <td>€10,00</td>
                    </tr>
                    <tr class="total-row">
                        <td colspan="2">Subtotale Bambino 3-8</td>
                        <td>€146,30</td>
                    </tr>
                    
                    <tr>
                        <td>1 Bambino 8-12 base</td>
                        <td>1 × €119,25</td>
                        <td>€119,25</td>
                    </tr>
                    <tr>
                        <td>Supplemento base</td>
                        <td>1 × €10,00</td>
                        <td>€10,00</td>
                    </tr>
                    <tr>
                        <td>Notte extra</td>
                        <td>1 × €20,00</td>
                        <td>€20,00</td>
                    </tr>
                    <tr>
                        <td>Supplemento extra</td>
                        <td>1 × €10,00</td>
                        <td>€10,00</td>
                    </tr>
                    <tr class="total-row">
                        <td colspan="2">Subtotale Bambino 8-12</td>
                        <td>€159,25</td>
                    </tr>
                    
                    <tr class="total-row" style="font-size: 1.2em;">
                        <td colspan="2">TOTALE CORRETTO</td>
                        <td>€743,55</td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="warning">
            <h2>🤔 Possibili Cause</h2>
            <ol>
                <li><strong>Notte extra adulti €80 invece di €40:</strong>
                    <ul>
                        <li>Potrebbe essere che il prezzo della notte extra sia per 2 notti invece di 1</li>
                        <li>O che sia configurato diversamente nel backend di produzione</li>
                    </ul>
                </li>
                <li><strong>Prezzi bambini diversi:</strong>
                    <ul>
                        <li>Le percentuali bambini potrebbero essere diverse in produzione</li>
                        <li>O i prezzi base del pacchetto sono diversi</li>
                    </ul>
                </li>
                <li><strong>Versione plugin:</strong>
                    <ul>
                        <li>Produzione potrebbe avere una versione diversa senza il fix del supplemento base</li>
                    </ul>
                </li>
            </ol>
        </div>

        <div class="section">
            <h2>🔧 Azioni da Verificare</h2>
            <ol>
                <li><strong>Controlla la configurazione del pacchetto in produzione:</strong>
                    <ul>
                        <li>Prezzo notte extra per adulti (dovrebbe essere €40, non €80)</li>
                        <li>Percentuali bambini per le fasce d'età</li>
                    </ul>
                </li>
                <li><strong>Verifica la versione del plugin in produzione:</strong>
                    <ul>
                        <li>Deve essere almeno v1.0.33 per avere il fix del supplemento base</li>
                        <li>Svuota cache browser (Ctrl+F5)</li>
                    </ul>
                </li>
                <li><strong>Debug in produzione:</strong>
                    <div class="code">
// Apri la console JavaScript e verifica:
console.log('[DEBUG] Prezzo notte extra adulti:', extraNightPP);
console.log('[DEBUG] Supplemento base notti:', basePackageNights);
console.log('[DEBUG] Prezzi bambini:', {
    f1: priceChildF1,
    f2: priceChildF2
});
                    </div>
                </li>
            </ol>
        </div>

        <div class="error">
            <h2>📊 Differenze Chiave</h2>
            <table>
                <tr>
                    <th>Elemento</th>
                    <th>Produzione</th>
                    <th>Locale (Corretto)</th>
                    <th>Differenza</th>
                </tr>
                <tr class="highlight">
                    <td>Notte extra adulti (per 2)</td>
                    <td>€160,00</td>
                    <td>€80,00</td>
                    <td>+€80,00</td>
                </tr>
                <tr>
                    <td>Bambino 3-8 totale</td>
                    <td>€159,01</td>
                    <td>€146,30</td>
                    <td>+€12,71</td>
                </tr>
                <tr>
                    <td>Bambino 8-12 totale</td>
                    <td>€177,20</td>
                    <td>€159,25</td>
                    <td>+€17,95</td>
                </tr>
                <tr class="total-row">
                    <td>TOTALE</td>
                    <td>€874,21</td>
                    <td>€743,55</td>
                    <td>+€130,66</td>
                </tr>
            </table>
        </div>
    </div>
</body>
</html>