<?php
/**
 * Gestione pagamenti individuali per prenotazioni di gruppo
 * 
 * Gestisce la creazione di link di pagamento personalizzati per ogni partecipante
 * di una prenotazione di gruppo, permettendo pagamenti individuali separati.
 * 
 * @since 1.0.14
 * @author Born To Ride Booking
 */

if (!defined('ABSPATH')) {
    exit;
}

class BTR_Group_Payments {
    
    /**
     * Durata validità link pagamento in ore
     */
    const PAYMENT_LINK_EXPIRY_HOURS = 72;
    
    /**
     * Prefisso per gli hash dei pagamenti
     */
    const PAYMENT_HASH_PREFIX = 'btr_pay_';

    public function __construct() {
        add_action('init', [$this, 'init_hooks']);
        add_action('template_redirect', [$this, 'handle_payment_page']);
        
        // AJAX endpoints
        add_action('wp_ajax_btr_generate_group_payment_links', [$this, 'ajax_generate_group_payment_links']);
        add_action('wp_ajax_btr_generate_individual_payment_link', [$this, 'ajax_generate_individual_payment_link']);
        add_action('wp_ajax_btr_send_payment_email', [$this, 'ajax_send_payment_email']);
        add_action('wp_ajax_nopriv_btr_process_individual_payment', [$this, 'ajax_process_individual_payment']);
        
        // WooCommerce hooks
        add_action('woocommerce_thankyou', [$this, 'handle_individual_payment_completion'], 10, 1);
        
        // Cleanup expired links
        add_action('btr_cleanup_expired_payment_links', [$this, 'cleanup_expired_links']);
        if (!wp_next_scheduled('btr_cleanup_expired_payment_links')) {
            wp_schedule_event(time(), 'daily', 'btr_cleanup_expired_payment_links');
        }

        // Admin menu
        add_action('admin_menu', [$this, 'add_admin_menu']);
    }

    public function init_hooks() {
        // Registra le rewrite rules per i link di pagamento
        add_action('init', [$this, 'add_rewrite_rules']);
        
        // Registra custom query vars per il routing
        add_filter('query_vars', [$this, 'add_query_vars']);
        add_action('parse_request', [$this, 'parse_payment_request']);
    }

    /**
     * Registra le rewrite rules per i link di pagamento
     * 
     * @since 1.0.99
     */
    public function add_rewrite_rules() {
        // Pattern per intercettare /pay-individual/{hash}/
        // Hash SHA256 = 64 caratteri esadecimali
        add_rewrite_rule(
            '^pay-individual/([a-f0-9]{64})/?$',
            'index.php?btr_payment_action=individual&btr_payment_hash=$matches[1]',
            'top'
        );
        
        // Pattern alternativo per compatibilità
        add_rewrite_rule(
            '^btr-payment/([a-f0-9]{64})/?$', 
            'index.php?btr_payment_action=individual&btr_payment_hash=$matches[1]',
            'top'
        );
        
        // Pattern per la pagina di riepilogo link di pagamento
        add_rewrite_rule(
            '^payment-links-summary/?$',
            'index.php?btr_payment_action=links_summary',
            'top'
        );
    }

    /**
     * Aggiunge query vars personalizzate
     */
    public function add_query_vars($vars) {
        $vars[] = 'btr_payment_hash';
        $vars[] = 'btr_payment_action';
        return $vars;
    }

    /**
     * Analizza le richieste di pagamento
     * 
     * Con le rewrite rules registrate, questo metodo ora serve come fallback
     * e per debug/logging delle richieste di pagamento
     */
    public function parse_payment_request($wp) {
        // Le query vars dovrebbero già essere impostate dalle rewrite rules
        // Questo serve come fallback e per debug
        if (!empty($wp->query_vars['btr_payment_hash']) && !empty($wp->query_vars['btr_payment_action'])) {
            // Log per debug (solo se BTR_DEBUG è attivo)
            if (defined('BTR_DEBUG') && BTR_DEBUG) {
                btr_debug_log('Payment request intercepted: ' . $wp->query_vars['btr_payment_hash']);
            }
            return;
        }
        
        // Fallback: Intercetta URL come /pay-individual/{hash} se le rewrite rules non funzionano
        if (isset($wp->request) && preg_match('#^pay-individual/([a-f0-9]{64})/?$#i', $wp->request, $matches)) {
            $wp->query_vars['btr_payment_hash'] = $matches[1];
            $wp->query_vars['btr_payment_action'] = 'individual';
            
            if (defined('BTR_DEBUG') && BTR_DEBUG) {
                btr_debug_log('Payment request intercepted via fallback: ' . $matches[1]);
            }
        }
    }

    /**
     * Gestisce la visualizzazione della pagina di pagamento
     * 
     * @since 1.0.99 - Migliorato per supportare le rewrite rules
     */
    public function handle_payment_page() {
        $payment_hash = get_query_var('btr_payment_hash', false);
        $payment_action = get_query_var('btr_payment_action', false);

        // Debug logging
        if (defined('BTR_DEBUG') && BTR_DEBUG) {
            btr_debug_log('Handle payment page - Hash: ' . $payment_hash . ', Action: ' . $payment_action);
        }

        if ($payment_hash && $payment_action === 'individual') {
            // Previeni caching della pagina
            nocache_headers();
            
            // Imposta headers corretti
            status_header(200);
            
            // Renderizza la pagina di pagamento
            $this->render_individual_payment_page($payment_hash);
            exit;
        } elseif ($payment_action === 'links_summary') {
            // Gestisci la pagina di riepilogo link
            nocache_headers();
            status_header(200);
            
            // Carica header WordPress
            get_header();
            
            // Renderizza il template di riepilogo
            echo do_shortcode('[btr_payment_links_summary]');
            
            // Carica footer WordPress
            get_footer();
            exit;
        }
    }

    /**
     * Genera link di pagamento individuali per tutti i partecipanti di un preventivo
     */
    public function generate_group_payment_links($preventivo_id, $payment_type = 'full') {
        global $wpdb;

        $anagrafici = get_post_meta($preventivo_id, '_anagrafici_preventivo', true);
        if (empty($anagrafici) || !is_array($anagrafici)) {
            return new WP_Error('no_participants', 'Nessun partecipante trovato nel preventivo');
        }

        $prezzo_totale = (float) get_post_meta($preventivo_id, '_prezzo_totale', true);
        $num_participants = count($anagrafici);
        
        if ($num_participants === 0) {
            return new WP_Error('division_by_zero', 'Numero partecipanti non valido');
        }

        $amount_per_person = $prezzo_totale / $num_participants;
        $links = [];
        
        $table_payments = $wpdb->prefix . 'btr_group_payments';
        $table_links = $wpdb->prefix . 'btr_payment_links';

        foreach ($anagrafici as $index => $participant) {
            $participant_name = trim(($participant['nome'] ?? '') . ' ' . ($participant['cognome'] ?? ''));
            $participant_email = $participant['email'] ?? '';

            if (empty($participant_email)) {
                continue; // Salta partecipanti senza email
            }

            // Genera hash sicuro per il pagamento
            $payment_hash = $this->generate_secure_hash($preventivo_id, $index, $participant_email);
            
            // Inserisci record pagamento
            $payment_data = [
                'preventivo_id' => $preventivo_id,
                'participant_index' => $index,
                'participant_name' => $participant_name,
                'participant_email' => $participant_email,
                'amount' => $amount_per_person,
                'payment_status' => 'pending',
                'payment_type' => $payment_type,
                'payment_hash' => $payment_hash,
                'created_at' => current_time('mysql'),
                'expires_at' => date('Y-m-d H:i:s', strtotime('+' . self::PAYMENT_LINK_EXPIRY_HOURS . ' hours'))
            ];

            $result = $wpdb->insert($table_payments, $payment_data);
            
            if ($result === false) {
                continue; // Salta in caso di errore
            }

            $payment_id = $wpdb->insert_id;

            // Genera hash per il link
            $link_hash = $this->generate_link_hash($payment_id, $payment_hash);
            
            // Inserisci link di pagamento
            $link_data = [
                'payment_id' => $payment_id,
                'link_hash' => $link_hash,
                'link_type' => 'individual',
                'created_at' => current_time('mysql'),
                'expires_at' => date('Y-m-d H:i:s', strtotime('+' . self::PAYMENT_LINK_EXPIRY_HOURS . ' hours'))
            ];

            $wpdb->insert($table_links, $link_data);

            $links[] = [
                'payment_id' => $payment_id,
                'participant_name' => $participant_name,
                'participant_email' => $participant_email,
                'amount' => $amount_per_person,
                'payment_url' => home_url('/pay-individual/' . $link_hash),
                'expires_at' => $link_data['expires_at']
            ];
        }

        return $links;
    }

    /**
     * Genera hash sicuro per il pagamento
     */
    private function generate_secure_hash($preventivo_id, $participant_index, $email) {
        $data = $preventivo_id . '|' . $participant_index . '|' . $email . '|' . time() . '|' . wp_generate_password(32, false);
        return hash('sha256', $data);
    }

    /**
     * Genera hash per il link di pagamento
     */
    private function generate_link_hash($payment_id, $payment_hash) {
        $data = $payment_id . '|' . $payment_hash . '|' . time() . '|' . wp_generate_password(32, false);
        return hash('sha256', $data);
    }

    /**
     * Renderizza la pagina di pagamento individuale
     */
    private function render_individual_payment_page($link_hash) {
        global $wpdb;

        // Verifica validità del link
        $link_data = $this->get_payment_link_data($link_hash);
        
        if (!$link_data) {
            wp_die('Link di pagamento non valido o scaduto.', 'Errore Pagamento', ['response' => 404]);
        }

        // Aggiorna contatore accessi
        $this->update_link_access($link_data['link_id']);

        // Carica template di pagamento
        $this->load_payment_template($link_data);
    }

    /**
     * Recupera i dati del link di pagamento
     */
    private function get_payment_link_data($link_hash) {
        global $wpdb;

        $table_links = $wpdb->prefix . 'btr_payment_links';
        $table_payments = $wpdb->prefix . 'btr_group_payments';

        $sql = $wpdb->prepare("
            SELECT l.*, p.* 
            FROM {$table_links} l
            INNER JOIN {$table_payments} p ON l.payment_id = p.payment_id
            WHERE l.link_hash = %s 
            AND l.is_active = 1 
            AND l.expires_at > NOW()
            AND p.payment_status = 'pending'
        ", $link_hash);

        return $wpdb->get_row($sql, ARRAY_A);
    }

    /**
     * Aggiorna il contatore di accessi al link
     */
    private function update_link_access($link_id) {
        global $wpdb;
        
        $table_links = $wpdb->prefix . 'btr_payment_links';
        
        $wpdb->update(
            $table_links,
            [
                'access_count' => new \stdClass(), // Incrementa
                'last_access_at' => current_time('mysql')
            ],
            ['link_id' => $link_id]
        );
        
        // Aggiorna manualmente il contatore
        $wpdb->query($wpdb->prepare(
            "UPDATE {$table_links} SET access_count = access_count + 1 WHERE link_id = %d",
            $link_id
        ));
    }

    /**
     * Carica il template di pagamento
     */
    private function load_payment_template($payment_data) {
        // Imposta dati per il template
        $template_vars = [
            'participant_name' => $payment_data['participant_name'],
            'amount' => $payment_data['amount'],
            'preventivo_id' => $payment_data['preventivo_id'],
            'payment_hash' => $payment_data['payment_hash'],
            'expires_at' => $payment_data['expires_at']
        ];

        // Carica header WordPress
        get_header();

        // Renderizza template custom
        echo $this->render_payment_form($template_vars);

        // Carica footer WordPress  
        get_footer();
    }

    /**
     * Renderizza il form di pagamento
     */
    private function render_payment_form($vars) {
        extract($vars);
        
        ob_start();
        ?>
        <div class="btr-individual-payment-container">
            <div class="btr-payment-header">
                <h1>Pagamento Individuale</h1>
                <p>Completa il tuo pagamento per la prenotazione</p>
            </div>

            <div class="btr-payment-details">
                <h3>Dettagli Pagamento</h3>
                <table class="btr-payment-summary">
                    <tr>
                        <td><strong>Partecipante:</strong></td>
                        <td><?= esc_html($participant_name) ?></td>
                    </tr>
                    <tr>
                        <td><strong>Importo:</strong></td>
                        <td>€<?= number_format($amount, 2, ',', '.') ?></td>
                    </tr>
                    <tr>
                        <td><strong>Scadenza:</strong></td>
                        <td><?= date('d/m/Y H:i', strtotime($expires_at)) ?></td>
                    </tr>
                </table>
            </div>

            <div class="btr-payment-form">
                <form id="btr-individual-payment-form" method="post" action="<?= esc_url(wc_get_checkout_url()) ?>">
                    <input type="hidden" name="btr_payment_hash" value="<?= esc_attr($payment_hash) ?>">
                    <input type="hidden" name="btr_payment_type" value="individual">
                    
                    <button type="submit" class="btr-payment-submit-btn">
                        Procedi al Pagamento - €<?= number_format($amount, 2, ',', '.') ?>
                    </button>
                </form>
            </div>
        </div>

        <style>
        .btr-individual-payment-container {
            max-width: 600px;
            margin: 2rem auto;
            padding: 2rem;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .btr-payment-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .btr-payment-header h1 {
            color: #0097c5;
            margin-bottom: 0.5rem;
        }
        
        .btr-payment-summary {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 2rem;
        }
        
        .btr-payment-summary td {
            padding: 0.75rem;
            border-bottom: 1px solid #eee;
        }
        
        .btr-payment-submit-btn {
            width: 100%;
            padding: 1rem 2rem;
            background: #0097c5;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 1.1rem;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .btr-payment-submit-btn:hover {
            background: #007ba3;
        }
        </style>
        <?php
        return ob_get_clean();
    }

    /**
     * AJAX: Genera link di pagamento per gruppo
     */
    public function ajax_generate_group_payment_links() {
        check_ajax_referer('btr_group_payments', 'nonce');

        if (!current_user_can('edit_posts')) {
            wp_die('Autorizzazione negata');
        }

        $preventivo_id = intval($_POST['preventivo_id'] ?? 0);
        $payment_type = sanitize_text_field($_POST['payment_type'] ?? 'full');

        if (!$preventivo_id) {
            wp_send_json_error('ID preventivo non valido');
        }

        $links = $this->generate_group_payment_links($preventivo_id, $payment_type);

        if (is_wp_error($links)) {
            wp_send_json_error($links->get_error_message());
        }

        wp_send_json_success([
            'links' => $links,
            'message' => 'Link di pagamento generati con successo'
        ]);
    }

    /**
     * Gestisce il completamento del pagamento individuale
     */
    public function handle_individual_payment_completion($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        // Verifica se è un pagamento individuale
        $payment_hash = $order->get_meta('_btr_payment_hash');
        if (!$payment_hash) {
            return;
        }

        // Aggiorna status pagamento
        $this->update_payment_status($payment_hash, 'paid', $order_id);
        
        // Invia notifiche
        $this->send_payment_confirmation($payment_hash, $order_id);
    }

    /**
     * Aggiorna lo status del pagamento
     */
    private function update_payment_status($payment_hash, $status, $order_id = null) {
        global $wpdb;
        
        $table_payments = $wpdb->prefix . 'btr_group_payments';
        
        $update_data = [
            'payment_status' => $status,
            'paid_at' => current_time('mysql')
        ];
        
        if ($order_id) {
            $update_data['wc_order_id'] = $order_id;
        }
        
        $wpdb->update(
            $table_payments,
            $update_data,
            ['payment_hash' => $payment_hash]
        );
    }

    /**
     * Invia email di conferma pagamento
     */
    private function send_payment_confirmation($payment_hash, $order_id) {
        global $wpdb;
        
        // Recupera dati pagamento dal hash
        $payment = $wpdb->get_row($wpdb->prepare(
            "SELECT payment_id FROM {$wpdb->prefix}btr_group_payments WHERE payment_hash = %s",
            $payment_hash
        ));
        
        if (!$payment) {
            return false;
        }
        
        // Utilizza il payment email manager per inviare la conferma
        if (class_exists('BTR_Payment_Email_Manager')) {
            $email_manager = BTR_Payment_Email_Manager::get_instance();
            
            // Trigger l'azione che invierà l'email
            do_action('btr_payment_completed', $payment->payment_id, $order_id);
            
            return true;
        }
        
        return false;
    }

    /**
     * Pulisce i link di pagamento scaduti
     */
    public function cleanup_expired_links() {
        global $wpdb;

        $table_links = $wpdb->prefix . 'btr_payment_links';
        $table_payments = $wpdb->prefix . 'btr_group_payments';

        // Disattiva link scaduti
        $wpdb->query("
            UPDATE {$table_links} 
            SET is_active = 0 
            WHERE expires_at < NOW() AND is_active = 1
        ");

        // Marca come scaduti i pagamenti non completati
        $wpdb->query("
            UPDATE {$table_payments} 
            SET payment_status = 'expired' 
            WHERE expires_at < NOW() AND payment_status = 'pending'
        ");
    }

    /**
     * Ottieni statistiche pagamenti per un preventivo
     */
    public function get_payment_stats($preventivo_id) {
        global $wpdb;
        
        $table_payments = $wpdb->prefix . 'btr_group_payments';
        
        $stats = $wpdb->get_row($wpdb->prepare("
            SELECT 
                COUNT(*) as total_payments,
                SUM(CASE WHEN payment_status = 'paid' THEN 1 ELSE 0 END) as paid_count,
                SUM(CASE WHEN payment_status = 'pending' THEN 1 ELSE 0 END) as pending_count,
                SUM(CASE WHEN payment_status = 'paid' THEN amount ELSE 0 END) as paid_amount,
                SUM(amount) as total_amount
            FROM {$table_payments}
            WHERE preventivo_id = %d
        ", $preventivo_id), ARRAY_A);

        return $stats;
    }

    /**
     * AJAX: Genera link di pagamento per singolo partecipante
     */
    public function ajax_generate_individual_payment_link() {
        check_ajax_referer('btr_group_payments', 'nonce');

        if (!current_user_can('edit_posts')) {
            wp_die('Autorizzazione negata');
        }

        $preventivo_id = intval($_POST['preventivo_id'] ?? 0);
        $participant_index = intval($_POST['participant_index'] ?? -1);

        if (!$preventivo_id || $participant_index < 0) {
            wp_send_json_error('Dati non validi');
        }

        $anagrafici = get_post_meta($preventivo_id, '_anagrafici_preventivo', true);
        if (empty($anagrafici[$participant_index])) {
            wp_send_json_error('Partecipante non trovato');
        }

        // Genera link solo per questo partecipante
        $result = $this->generate_individual_payment_link($preventivo_id, $participant_index);

        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        }

        // Invia email automaticamente
        $email_sent = $this->send_payment_link_email($result['payment_id']);

        wp_send_json_success([
            'link' => $result,
            'email_sent' => $email_sent,
            'message' => 'Link di pagamento generato e email inviata con successo'
        ]);
    }

    /**
     * Genera link di pagamento per un singolo partecipante
     */
    public function generate_individual_payment_link($preventivo_id, $participant_index) {
        global $wpdb;

        $anagrafici = get_post_meta($preventivo_id, '_anagrafici_preventivo', true);
        if (empty($anagrafici[$participant_index])) {
            return new WP_Error('participant_not_found', 'Partecipante non trovato');
        }

        $participant = $anagrafici[$participant_index];
        $participant_name = trim(($participant['nome'] ?? '') . ' ' . ($participant['cognome'] ?? ''));
        $participant_email = $participant['email'] ?? '';

        if (empty($participant_email)) {
            return new WP_Error('no_email', 'Email del partecipante non trovata');
        }

        $prezzo_totale = (float) get_post_meta($preventivo_id, '_prezzo_totale', true);
        $num_participants = count($anagrafici);
        $amount_per_person = $prezzo_totale / $num_participants;

        $table_payments = $wpdb->prefix . 'btr_group_payments';
        $table_links = $wpdb->prefix . 'btr_payment_links';

        // Verifica se esiste già un pagamento pendente
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT payment_id FROM {$table_payments} 
             WHERE preventivo_id = %d AND participant_index = %d 
             AND payment_status = 'pending' AND expires_at > NOW()",
            $preventivo_id, $participant_index
        ));

        if ($existing) {
            return new WP_Error('payment_exists', 'Esiste già un pagamento pendente per questo partecipante');
        }

        // Genera hash sicuro
        $payment_hash = $this->generate_secure_hash($preventivo_id, $participant_index, $participant_email);
        
        // Inserisci record pagamento
        $payment_data = [
            'preventivo_id' => $preventivo_id,
            'participant_index' => $participant_index,
            'participant_name' => $participant_name,
            'participant_email' => $participant_email,
            'amount' => $amount_per_person,
            'payment_status' => 'pending',
            'payment_type' => 'full',
            'payment_hash' => $payment_hash,
            'created_at' => current_time('mysql'),
            'expires_at' => date('Y-m-d H:i:s', strtotime('+' . self::PAYMENT_LINK_EXPIRY_HOURS . ' hours'))
        ];

        $result = $wpdb->insert($table_payments, $payment_data);
        
        if ($result === false) {
            return new WP_Error('db_error', 'Errore nella creazione del pagamento');
        }

        $payment_id = $wpdb->insert_id;

        // Genera hash per il link
        $link_hash = $this->generate_link_hash($payment_id, $payment_hash);
        
        // Inserisci link di pagamento
        $link_data = [
            'payment_id' => $payment_id,
            'link_hash' => $link_hash,
            'link_type' => 'individual',
            'created_at' => current_time('mysql'),
            'expires_at' => date('Y-m-d H:i:s', strtotime('+' . self::PAYMENT_LINK_EXPIRY_HOURS . ' hours'))
        ];

        $wpdb->insert($table_links, $link_data);

        return [
            'payment_id' => $payment_id,
            'participant_name' => $participant_name,
            'participant_email' => $participant_email,
            'amount' => $amount_per_person,
            'payment_url' => home_url('/pay-individual/' . $link_hash),
            'expires_at' => $link_data['expires_at']
        ];
    }

    /**
     * AJAX: Invia email di pagamento
     */
    public function ajax_send_payment_email() {
        check_ajax_referer('btr_group_payments', 'nonce');

        if (!current_user_can('edit_posts')) {
            wp_die('Autorizzazione negata');
        }

        $payment_id = intval($_POST['payment_id'] ?? 0);

        if (!$payment_id) {
            wp_send_json_error('ID pagamento non valido');
        }

        $result = $this->send_payment_link_email($payment_id);

        if ($result) {
            wp_send_json_success('Email inviata con successo');
        } else {
            wp_send_json_error('Errore nell\'invio dell\'email');
        }
    }

    /**
     * Invia email con link di pagamento
     */
    public function send_payment_link_email($payment_id) {
        global $wpdb;

        $table_payments = $wpdb->prefix . 'btr_group_payments';
        $table_links = $wpdb->prefix . 'btr_payment_links';

        // Ottieni dati pagamento e link
        $payment_data = $wpdb->get_row($wpdb->prepare(
            "SELECT p.*, l.link_hash 
             FROM {$table_payments} p
             LEFT JOIN {$table_links} l ON p.payment_id = l.payment_id
             WHERE p.payment_id = %d AND l.is_active = 1",
            $payment_id
        ), ARRAY_A);

        if (!$payment_data) {
            return false;
        }

        // Ottieni dati preventivo
        $preventivo_id = $payment_data['preventivo_id'];
        $nome_pacchetto = get_post_meta($preventivo_id, '_nome_pacchetto', true);
        $date_range = get_post_meta($preventivo_id, '_date_ranges', true);

        $payment_url = home_url('/pay-individual/' . $payment_data['link_hash']);
        $expires_date = date('d/m/Y H:i', strtotime($payment_data['expires_at']));

        // Componi email
        $to = $payment_data['participant_email'];
        $subject = 'Link per il pagamento individuale - ' . $nome_pacchetto;
        
        $message = "
        <html>
        <body style='font-family: Arial, sans-serif; line-height: 1.6; color: #333;'>
            <div style='max-width: 600px; margin: 0 auto; padding: 20px;'>
                <h2 style='color: #0097c5;'>Pagamento Individuale</h2>
                
                <p>Ciao <strong>{$payment_data['participant_name']}</strong>,</p>
                
                <p>È stato generato il tuo link personalizzato per il pagamento della quota individuale per:</p>
                
                <div style='background: #f9f9f9; padding: 15px; border-left: 4px solid #0097c5; margin: 20px 0;'>
                    <h3 style='margin: 0 0 10px;'>{$nome_pacchetto}</h3>
                    " . ($date_range ? "<p><strong>Date:</strong> {$date_range}</p>" : "") . "
                    <p><strong>Tua quota:</strong> €" . number_format($payment_data['amount'], 2, ',', '.') . "</p>
                </div>
                
                <p style='text-align: center; margin: 30px 0;'>
                    <a href='{$payment_url}' 
                       style='background: #0097c5; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;'>
                        Procedi al Pagamento
                    </a>
                </p>
                
                <div style='background: #fff3cd; padding: 10px; border-radius: 4px; margin: 20px 0;'>
                    <p style='margin: 0;'><strong>⚠️ Importante:</strong> Questo link scade il <strong>{$expires_date}</strong></p>
                </div>
                
                <hr style='margin: 30px 0; border: none; height: 1px; background: #ddd;'>
                
                <p style='font-size: 14px; color: #666;'>
                    Se hai problemi con il link, contattaci direttamente.<br>
                    Questo è un messaggio automatico, non rispondere a questa email.
                </p>
            </div>
        </body>
        </html>
        ";

        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . get_bloginfo('name') . ' <' . get_option('admin_email') . '>'
        ];

        return wp_mail($to, $subject, $message, $headers);
    }

    /**
     * Aggiunge menu admin per gestione pagamenti
     */
    public function add_admin_menu() {
        add_submenu_page(
            'edit.php?post_type=preventivo',
            'Pagamenti di Gruppo',
            'Pagamenti di Gruppo',
            'edit_posts',
            'btr-group-payments',
            [$this, 'admin_page']
        );
    }

    /**
     * Renderizza la pagina admin
     */
    public function admin_page() {
        $preventivo_id = intval($_GET['preventivo_id'] ?? 0);
        
        if ($preventivo_id) {
            include BTR_PLUGIN_DIR . 'admin/views/group-payments.php';
        } else {
            echo '<div class="wrap"><h1>Seleziona un preventivo per gestire i pagamenti di gruppo.</h1></div>';
        }
    }
}