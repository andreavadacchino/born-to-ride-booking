<?php
/**
 * Force cache clear and debug check
 * 
 * @package Born_To_Ride_Booking
 */

// Carica WordPress
if (!defined('ABSPATH')) {
    require_once('../../../wp-load.php');
}

// Solo per admin
if (!current_user_can('manage_options')) {
    wp_die('Non autorizzato');
}

echo '<h2>🧹 Force Cache Clear & Debug Check</h2>';

// 1. Clear WooCommerce cache
if (function_exists('wc_delete_product_transients')) {
    wc_delete_product_transients();
    echo '<p>✅ WooCommerce product transients cleared</p>';
}

// 2. Clear WordPress object cache
if (function_exists('wp_cache_flush')) {
    wp_cache_flush();
    echo '<p>✅ WordPress object cache flushed</p>';
}

// 3. Clear WooCommerce sessions
if (WC()->session) {
    WC()->session->destroy_session();
    echo '<p>✅ WooCommerce session destroyed</p>';
}

// 4. Force reload browser cache (CSS/JS)
$timestamp = time();
echo '<p>🔄 Browser cache buster: ' . $timestamp . '</p>';
echo '<script>
if (typeof localStorage !== "undefined") {
    localStorage.clear();
    sessionStorage.clear();
    console.log("Local storage cleared");
}
</script>';

// 5. Check debug settings
echo '<h3>🔧 Debug Settings</h3>';
echo '<p>WP_DEBUG: ' . (defined('WP_DEBUG') && WP_DEBUG ? '✅ ON' : '❌ OFF') . '</p>';
echo '<p>BTR_DEBUG: ' . (defined('BTR_DEBUG') && BTR_DEBUG ? '✅ ON' : '❌ OFF') . '</p>';
echo '<p>Debug log file: ' . (is_writable(WP_CONTENT_DIR . '/debug.log') ? '✅ Writable' : '❌ Not writable') . '</p>';

// 6. Test btr_price_calculator availability
echo '<h3>🧮 BTR Price Calculator Test</h3>';
if (function_exists('btr_price_calculator')) {
    $calc = btr_price_calculator();
    if (is_object($calc)) {
        echo '<p>✅ btr_price_calculator() disponibile</p>';
        if (method_exists($calc, 'calculate_extra_costs')) {
            echo '<p>✅ Metodo calculate_extra_costs() disponibile</p>';
        } else {
            echo '<p>❌ Metodo calculate_extra_costs() NON disponibile</p>';
        }
    } else {
        echo '<p>❌ btr_price_calculator() non restituisce un oggetto</p>';
    }
} else {
    echo '<p>❌ Funzione btr_price_calculator() NON disponibile</p>';
}

// 7. Test BTR_Checkout class
echo '<h3>🛒 BTR_Checkout Class Test</h3>';
if (class_exists('BTR_Checkout')) {
    $checkout = BTR_Checkout::instance();
    if (method_exists($checkout, 'get_summary_html')) {
        echo '<p>✅ BTR_Checkout::get_summary_html() disponibile</p>';
    } else {
        echo '<p>❌ Metodo get_summary_html() NON disponibile</p>';
    }
} else {
    echo '<p>❌ Classe BTR_Checkout NON disponibile</p>';
}

// 8. Force debug log entry
error_log('BTR Force Cache Clear - Timestamp: ' . date('Y-m-d H:i:s'));
echo '<p>✅ Debug log entry forced</p>';

echo '<hr>';
echo '<p><strong>🎯 Prossimi passi:</strong></p>';
echo '<ol>';
echo '<li>Svuota cache del browser (Ctrl+F5 o Cmd+Shift+R)</li>';
echo '<li>Vai a una pagina checkout di test</li>';
echo '<li>Controlla debug.log per nuovi log BTR</li>';
echo '<li>Se il problema persiste, potrebbe essere il summary React che non usa le nostre funzioni</li>';
echo '</ol>';

echo '<p><em>Generato: ' . date('Y-m-d H:i:s') . '</em></p>';