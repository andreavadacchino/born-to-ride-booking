<?php
/**
 * Born to Ride Booking - Professional Build Release Script
 * 
 * Questo script crea build di produzione del plugin seguendo le best practice WordPress
 * con versioning automatico per evitare problemi di cache.
 * 
 * @package Born_To_Ride_Booking
 * @version 1.0.0
 */

// Previeni accesso diretto
if (!defined('DOING_BUILD') && php_sapi_name() !== 'cli') {
    // Se eseguito da browser, verifica permessi WordPress
    $wp_load = find_wp_load();
    if ($wp_load) {
        define('DOING_BUILD', true);
        require_once($wp_load);
        if (!current_user_can('manage_options')) {
            wp_die('Accesso negato. Solo gli amministratori possono eseguire il build.');
        }
    } else {
        die('WordPress non trovato. Esegui questo script dalla directory del plugin.');
    }
}

// Costanti di configurazione
define('BTR_BUILD_PLUGIN_NAME', 'born-to-ride-booking');
define('BTR_BUILD_PLUGIN_DIR', dirname(__FILE__));
define('BTR_BUILD_DIR', BTR_BUILD_PLUGIN_DIR . '/build');
define('BTR_BUILD_TEMP_DIR', BTR_BUILD_DIR . '/temp-' . uniqid());

/**
 * Trova wp-load.php per caricare WordPress
 */
function find_wp_load() {
    $paths = [
        '../../../../wp-load.php',
        '../../../wp-load.php',
        dirname(__FILE__) . '/../../../../wp-load.php',
    ];
    
    // Supporto per Local by Flywheel
    if (strpos(__FILE__, '/Local Sites/') !== false) {
        preg_match('#/Local Sites/[^/]+/app/public/#', __FILE__, $matches);
        if (!empty($matches[0])) {
            $paths[] = $matches[0] . 'wp-load.php';
        }
    }
    
    foreach ($paths as $path) {
        if (file_exists($path)) {
            return $path;
        }
    }
    
    return false;
}

/**
 * Classe principale per gestire il build del plugin
 */
class BTR_Build_Manager {
    
    private $version;
    private $build_timestamp;
    private $exclude_dirs = [
        'tests',
        'build',
        '.git',
        '.github',
        'node_modules',
        '.idea',
        '.vscode',
        'vendor',
        'src', // Directory sorgenti non compilate
        'assets/src', // Sorgenti JS/CSS non compilate
    ];
    
    private $exclude_files = [
        '.gitignore',
        '.gitattributes',
        '.editorconfig',
        '.eslintrc.json',
        '.phpcs.xml',
        'phpunit.xml',
        'composer.json',
        'composer.lock',
        'package.json',
        'package-lock.json',
        'webpack.config.js',
        'gulpfile.js',
        '.DS_Store',
        'Thumbs.db',
        'build-plugin-zip.sh',
        'build-plugin-zip.php',
        'build-release.php',
        'build-release-pro.php',
        '.distignore',
        'phpstan.neon',
        '.env',
        '.env.example',
        'error_log',
        'debug.log',
        'php_error.log',
        'php_errors.log',
        '.htaccess',
        'web.config',
    ];
    
    private $exclude_patterns = [
        '*.log',
        '*.bak',
        '*.backup',
        '*.old',
        '*.orig',
        '*.tmp',
        '*.temp',
        '*.cache',
        '*.map', // Source maps
        'test-*.php',
        '*-test.php',
        'debug-*.php',
        'fix-*.php',
        '*.test.html',
        'MODIFICHE-*.md',
        'RIPRISTINO-*.md',
        'PUNTO-RIPRISTINO-*.md',
        'DOCUMENTAZIONE-MODIFICHE-*.md',
        'TODO*.md',
        'CHANGELOG-DEV.md',
        'RESTORE-POINT-*.md',
        'ajax-changelog-*.php', // File di sviluppo AJAX
        'test-changelog-*.php', // File di test
        'emergency-*.php',
        'emergency-*.html',
        'analyze-*.php',
        'DOCUMENTAZIONE-*.md',
        'PIANO-*.md',
        'test-*.html',
        'test-*.md',
        'class-btr-debug-*.php',
        'class-btr-hotfix-*.php',
        'admin-debug-*.css',
        'admin-debug-*.js',
        '*-debug-*.js',
        'hotfix-*.js',
        'ajax-test-*.php',
        '*.sql',
        '*.zip',
        '*.tar',
        '*.gz',
        'error_log*',
        'debug_log*',
    ];
    
    /**
     * Costruttore
     */
    public function __construct() {
        $this->build_timestamp = time();
        $this->extract_version();
    }
    
    /**
     * Estrae la versione dal file principale del plugin
     */
    private function extract_version() {
        $plugin_file = BTR_BUILD_PLUGIN_DIR . '/born-to-ride-booking.php';
        if (!file_exists($plugin_file)) {
            throw new Exception("File principale del plugin non trovato: {$plugin_file}");
        }
        
        $content = file_get_contents($plugin_file);
        if (preg_match('/Version:\s*(.+)/i', $content, $matches)) {
            $this->version = trim($matches[1]);
        } else {
            throw new Exception("Impossibile estrarre la versione dal file del plugin");
        }
    }
    
    /**
     * Esegue il processo di build completo
     */
    public function build() {
        $this->log("🚀 Inizio build di " . BTR_BUILD_PLUGIN_NAME . " v{$this->version}");
        
        try {
            // 1. Prepara directory
            $this->prepare_directories();
            
            // 2. Aggiorna versioni nei file
            $this->update_file_versions();
            
            // 3. Copia file nel temp
            $this->copy_files();
            
            // 4. Ottimizza assets
            $this->optimize_assets();
            
            // 5. Crea ZIP
            $zip_file = $this->create_zip();
            
            // 6. Cleanup
            $this->cleanup();
            
            // 7. Report finale
            $this->final_report($zip_file);
            
        } catch (Exception $e) {
            $this->error("❌ Errore durante il build: " . $e->getMessage());
            $this->cleanup();
            exit(1);
        }
    }
    
    /**
     * Prepara le directory per il build
     */
    private function prepare_directories() {
        $this->log("📁 Preparazione directory...");
        
        // Crea directory build se non esiste
        if (!is_dir(BTR_BUILD_DIR)) {
            mkdir(BTR_BUILD_DIR, 0755, true);
        }
        
        // Rimuovi temp precedenti
        $this->remove_old_temps();
        
        // Crea nuova directory temporanea
        mkdir(BTR_BUILD_TEMP_DIR, 0755, true);
    }
    
    /**
     * Aggiorna le versioni nei file per cache busting
     */
    private function update_file_versions() {
        $this->log("🔄 Aggiornamento versioni per cache busting...");
        
        // File da aggiornare con nuove versioni
        $files_to_update = [
            '/born-to-ride-booking.php' => [
                'pattern' => '/define\s*\(\s*[\'"]BTR_VERSION[\'"]\s*,\s*[\'"][^\'"]+[\'"]\s*\)/',
                'replacement' => "define('BTR_VERSION', '{$this->version}')"
            ],
            '/includes/class-btr-shortcodes.php' => [
                'callback' => [$this, 'update_asset_versions']
            ],
            '/includes/class-btr-shortcode-anagrafici.php' => [
                'callback' => [$this, 'update_asset_versions']
            ],
            '/includes/class-btr-frontend-display.php' => [
                'callback' => [$this, 'update_asset_versions']
            ],
        ];
        
        foreach ($files_to_update as $file => $config) {
            $filepath = BTR_BUILD_PLUGIN_DIR . $file;
            if (!file_exists($filepath)) {
                $this->log("  ⚠️  File non trovato: {$file}");
                continue;
            }
            
            $content = file_get_contents($filepath);
            
            if (isset($config['pattern'])) {
                // Sostituzione con pattern regex
                $content = preg_replace($config['pattern'], $config['replacement'], $content);
            } elseif (isset($config['callback'])) {
                // Usa callback per modifiche complesse
                $content = call_user_func($config['callback'], $content);
            }
            
            file_put_contents($filepath, $content);
            $this->log("  ✓ Aggiornato: {$file}");
        }
    }
    
    /**
     * Aggiorna le versioni degli assets nei file PHP
     */
    private function update_asset_versions($content) {
        // Pattern per wp_enqueue_script e wp_enqueue_style
        $patterns = [
            // wp_enqueue_script con BTR_VERSION
            '/wp_enqueue_script\s*\([^,]+,[^,]+,[^,]+,\s*BTR_VERSION/i',
            // wp_enqueue_style con BTR_VERSION  
            '/wp_enqueue_style\s*\([^,]+,[^,]+,[^,]+,\s*BTR_VERSION/i',
            // Versioni hardcoded tipo '1.0'
            '/wp_enqueue_(script|style)\s*\([^,]+,[^,]+,[^,]+,\s*[\'"][\d\.]+[\'"]/i',
        ];
        
        // Sostituisci tutte le versioni con BTR_VERSION per consistency
        foreach ($patterns as $pattern) {
            $content = preg_replace_callback($pattern, function($matches) {
                // Se già usa BTR_VERSION, lascia invariato
                if (stripos($matches[0], 'BTR_VERSION') !== false) {
                    return $matches[0];
                }
                
                // Altrimenti sostituisci la versione con BTR_VERSION
                return preg_replace('/[\'"][\d\.]+[\'"]$/', 'BTR_VERSION', $matches[0]);
            }, $content);
        }
        
        // Aggiungi timestamp ai file critici per forzare refresh
        $critical_assets = [
            'frontend-scripts.js',
            'anagrafici-scripts.js',
            'frontend-styles.css',
            'costi-extra-styles.css',
        ];
        
        foreach ($critical_assets as $asset) {
            $content = preg_replace(
                "/(plugin_dir_url.*{$asset}['\"])\s*,/",
                "$1 . '?v=' . BTR_VERSION . '.' . {$this->build_timestamp},",
                $content
            );
        }
        
        return $content;
    }
    
    /**
     * Copia i file nella directory temporanea
     */
    private function copy_files() {
        $this->log("📋 Copia file...");
        
        $source = BTR_BUILD_PLUGIN_DIR;
        $destination = BTR_BUILD_TEMP_DIR . '/' . BTR_BUILD_PLUGIN_NAME;
        
        $this->copy_directory($source, $destination);
        
        $this->log("  ✓ File copiati");
    }
    
    /**
     * Copia ricorsiva con esclusioni
     */
    private function copy_directory($source, $destination) {
        if (!is_dir($destination)) {
            mkdir($destination, 0755, true);
        }
        
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($source, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        
        foreach ($iterator as $file) {
            $filePath = $file->getPathname();
            $relativePath = str_replace($source . '/', '', $filePath);
            
            // Skip se in directory esclusa
            foreach ($this->exclude_dirs as $excludeDir) {
                if (strpos($relativePath, $excludeDir . '/') === 0 || $relativePath === $excludeDir) {
                    continue 2;
                }
            }
            
            if ($file->isDir()) {
                $destDir = $destination . '/' . $relativePath;
                if (!is_dir($destDir)) {
                    mkdir($destDir, 0755, true);
                }
            } else {
                $filename = $file->getFilename();
                
                // Skip file esclusi
                if (in_array($filename, $this->exclude_files)) {
                    continue;
                }
                
                // Skip pattern esclusi
                foreach ($this->exclude_patterns as $pattern) {
                    if (fnmatch($pattern, $filename)) {
                        continue 2;
                    }
                }
                
                // Copia il file
                copy($filePath, $destination . '/' . $relativePath);
            }
        }
    }
    
    /**
     * Ottimizza gli assets (placeholder per future ottimizzazioni)
     */
    private function optimize_assets() {
        $this->log("🎨 Ottimizzazione assets...");
        
        // Qui si potrebbero aggiungere:
        // - Minificazione JS/CSS
        // - Ottimizzazione immagini
        // - Rimozione commenti PHP
        
        $this->log("  ✓ Assets ottimizzati");
    }
    
    /**
     * Crea il file ZIP finale
     */
    private function create_zip() {
        $this->log("📦 Creazione ZIP...");
        
        $zip_filename = BTR_BUILD_PLUGIN_NAME . '-v' . $this->version . '.zip';
        $zip_path = BTR_BUILD_DIR . '/' . $zip_filename;
        
        $zip = new ZipArchive();
        if ($zip->open($zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== TRUE) {
            throw new Exception("Impossibile creare il file ZIP: {$zip_path}");
        }
        
        $source = BTR_BUILD_TEMP_DIR . '/' . BTR_BUILD_PLUGIN_NAME;
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($source),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        
        foreach ($files as $file) {
            if (!$file->isDir()) {
                $filePath = $file->getRealPath();
                $relativePath = BTR_BUILD_PLUGIN_NAME . '/' . 
                               substr($filePath, strlen($source) + 1);
                $zip->addFile($filePath, $relativePath);
            }
        }
        
        $zip->close();
        
        // Mantieni solo le ultime 5 versioni
        $this->cleanup_old_builds();
        
        $this->log("  ✓ ZIP creato: {$zip_filename}");
        
        return $zip_path;
    }
    
    /**
     * Rimuove build vecchie mantenendo solo le ultime N
     */
    private function cleanup_old_builds($keep = 5) {
        $pattern = BTR_BUILD_DIR . '/' . BTR_BUILD_PLUGIN_NAME . '-v*.zip';
        $files = glob($pattern);
        
        if (count($files) > $keep) {
            usort($files, function($a, $b) {
                return filemtime($a) - filemtime($b);
            });
            
            $files_to_remove = array_slice($files, 0, count($files) - $keep);
            foreach ($files_to_remove as $file) {
                unlink($file);
                $this->log("  🗑️  Rimossa vecchia build: " . basename($file));
            }
        }
    }
    
    /**
     * Pulisce le directory temporanee
     */
    private function cleanup() {
        if (is_dir(BTR_BUILD_TEMP_DIR)) {
            $this->remove_directory(BTR_BUILD_TEMP_DIR);
        }
        
        $this->remove_old_temps();
    }
    
    /**
     * Rimuove vecchie directory temporanee
     */
    private function remove_old_temps() {
        $temps = glob(BTR_BUILD_DIR . '/temp-*');
        foreach ($temps as $temp) {
            if (is_dir($temp)) {
                $this->remove_directory($temp);
            }
        }
    }
    
    /**
     * Rimuove ricorsivamente una directory
     */
    private function remove_directory($dir) {
        if (!is_dir($dir)) {
            return;
        }
        
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        
        foreach ($files as $fileinfo) {
            if ($fileinfo->isDir()) {
                rmdir($fileinfo->getRealPath());
            } else {
                unlink($fileinfo->getRealPath());
            }
        }
        
        rmdir($dir);
    }
    
    /**
     * Report finale del build
     */
    private function final_report($zip_path) {
        $size = filesize($zip_path);
        $size_formatted = $this->format_bytes($size);
        $filename = basename($zip_path);
        
        $this->log("\n✅ Build completata con successo!");
        $this->log("📦 File: {$filename}");
        $this->log("📏 Dimensione: {$size_formatted}");
        $this->log("🔖 Versione: {$this->version}");
        $this->log("🕒 Timestamp: " . date('Y-m-d H:i:s', $this->build_timestamp));
        
        $this->log("\n📋 Riepilogo esclusioni:");
        $this->log("  • Directory di sviluppo (tests, node_modules, etc.)");
        $this->log("  • File di configurazione sviluppo");  
        $this->log("  • File temporanei e di log");
        $this->log("  • Script di build");
        $this->log("  • File di documentazione sviluppatore");
        
        $this->log("\n🔧 Cache Busting:");
        $this->log("  • BTR_VERSION aggiornata a: {$this->version}");
        $this->log("  • Assets critici con timestamp: {$this->build_timestamp}");
        $this->log("  • Tutti gli enqueue utilizzano versioning consistente");
        
        if (php_sapi_name() !== 'cli') {
            $download_url = plugins_url('build/' . $filename, __FILE__);
            $this->log("\n<a href='{$download_url}' class='button button-primary' download>⬇️ Scarica {$filename}</a>");
        }
    }
    
    /**
     * Formatta i byte in formato leggibile
     */
    private function format_bytes($bytes, $precision = 2) {
        $units = ['B', 'KB', 'MB', 'GB'];
        
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        
        return round($bytes / pow(1024, $pow), $precision) . ' ' . $units[$pow];
    }
    
    /**
     * Log con formattazione
     */
    private function log($message) {
        if (php_sapi_name() === 'cli') {
            echo $message . "\n";
        } else {
            echo $message . "<br>\n";
        }
        
        flush();
    }
    
    /**
     * Log errore
     */
    private function error($message) {
        if (php_sapi_name() === 'cli') {
            fwrite(STDERR, $message . "\n");
        } else {
            echo "<div style='color: red; font-weight: bold;'>{$message}</div>\n";
        }
    }
}

// Output header appropriato
if (php_sapi_name() !== 'cli') {
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Build Release - Born to Ride Booking</title>
        <meta charset="utf-8">
        <style>
            body {
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                line-height: 1.6;
                max-width: 800px;
                margin: 40px auto;
                padding: 20px;
                background: #f5f5f5;
            }
            .container {
                background: white;
                padding: 30px;
                border-radius: 8px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            h1 {
                color: #333;
                border-bottom: 2px solid #0073aa;
                padding-bottom: 10px;
            }
            pre {
                background: #f0f0f0;
                padding: 20px;
                border-radius: 4px;
                overflow-x: auto;
                font-size: 14px;
                line-height: 1.4;
            }
            .button {
                display: inline-block;
                padding: 10px 20px;
                background: #0073aa;
                color: white;
                text-decoration: none;
                border-radius: 4px;
                margin-top: 20px;
            }
            .button:hover {
                background: #005a87;
            }
            .error {
                color: #d00;
                font-weight: bold;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🚀 Build Release - Born to Ride Booking</h1>
            <pre>
    <?php
}

// Esegui il build
try {
    $builder = new BTR_Build_Manager();
    $builder->build();
} catch (Exception $e) {
    if (php_sapi_name() === 'cli') {
        fwrite(STDERR, "❌ Errore fatale: " . $e->getMessage() . "\n");
        exit(1);
    } else {
        echo "<div class='error'>❌ Errore fatale: " . htmlspecialchars($e->getMessage()) . "</div>";
    }
}

// Chiudi HTML se necessario
if (php_sapi_name() !== 'cli') {
    ?>
            </pre>
        </div>
    </body>
    </html>
    <?php
}