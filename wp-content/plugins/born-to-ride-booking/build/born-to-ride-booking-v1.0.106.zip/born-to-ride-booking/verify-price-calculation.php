<?php
/**
 * Verifica calcolo prezzi con breakdown dettagliato
 */

// Load WordPress
$wp_load = false;
$paths_to_check = [
    '../../../../wp-load.php',
    dirname(__FILE__) . '/../../../../wp-load.php',
];

foreach ($paths_to_check as $path) {
    if (file_exists($path)) {
        $wp_load = $path;
        break;
    }
}

if ($wp_load) {
    require_once($wp_load);
} else {
    die('Errore: Impossibile trovare wp-load.php');
}

// Verifica permessi
if (!current_user_can('manage_options')) {
    wp_die('Accesso negato');
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Verifica Calcolo Prezzi</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 1000px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        h1 { color: #333; border-bottom: 3px solid #0097c5; padding-bottom: 15px; }
        .section { margin: 20px 0; padding: 20px; background: #f8f9fa; border-radius: 5px; }
        .calculation { margin: 10px 0; padding: 15px; background: white; border-left: 3px solid #0097c5; }
        .subtotal { font-weight: bold; color: #0097c5; margin-top: 10px; }
        .total { font-size: 1.2em; font-weight: bold; color: #28a745; padding: 15px; background: #d4edda; border-radius: 5px; margin: 20px 0; }
        .error { background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; }
        .warning { background: #fff3cd; color: #856404; padding: 15px; border-radius: 5px; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #f0f0f0; font-weight: bold; }
        .code { background: #e9ecef; padding: 10px; border-radius: 5px; font-family: monospace; margin: 10px 0; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🧮 Verifica Calcolo Prezzi</h1>
        
        <div class="section">
            <h2>📋 Scenario Test</h2>
            <ul>
                <li>2 Adulti in 2x Doppia/Matrimoniale</li>
                <li>1 Bambino 3-8 anni</li>
                <li>1 Bambino 8-12 anni</li>
                <li>1 Notte extra del 23/01/2026</li>
            </ul>
        </div>

        <div class="section">
            <h2>💰 Calcolo Dettagliato</h2>
            
            <div class="calculation">
                <h3>👥 2 Adulti</h3>
                <table>
                    <tr>
                        <td>Quota base (2 × €159,00)</td>
                        <td align="right">€318,00</td>
                    </tr>
                    <tr>
                        <td>Supplemento pacchetto (2 × €10,00 × 1 notte base)</td>
                        <td align="right">€20,00</td>
                    </tr>
                    <tr>
                        <td>Notte extra (2 × €40,00)</td>
                        <td align="right">€80,00</td>
                    </tr>
                    <tr>
                        <td>Supplemento notte extra (2 × €10,00)</td>
                        <td align="right">€20,00</td>
                    </tr>
                </table>
                <div class="subtotal">Totale Adulti: €438,00</div>
            </div>

            <div class="calculation">
                <h3>🧒 1 Bambino 3-8 anni</h3>
                <table>
                    <tr>
                        <td>Quota base</td>
                        <td align="right">€111,30</td>
                    </tr>
                    <tr>
                        <td>Supplemento pacchetto (1 notte base)</td>
                        <td align="right">€10,00</td>
                    </tr>
                    <tr>
                        <td>Notte extra</td>
                        <td align="right">€15,00</td>
                    </tr>
                    <tr>
                        <td>Supplemento notte extra</td>
                        <td align="right">€10,00</td>
                    </tr>
                </table>
                <div class="subtotal">Totale Bambino 3-8: €146,30</div>
            </div>

            <div class="calculation">
                <h3>👧 1 Bambino 8-12 anni</h3>
                <table>
                    <tr>
                        <td>Quota base</td>
                        <td align="right">€119,25</td>
                    </tr>
                    <tr>
                        <td>Supplemento pacchetto (1 notte base)</td>
                        <td align="right">€10,00</td>
                    </tr>
                    <tr>
                        <td>Notte extra</td>
                        <td align="right">€20,00</td>
                    </tr>
                    <tr>
                        <td>Supplemento notte extra</td>
                        <td align="right">€10,00</td>
                    </tr>
                </table>
                <div class="subtotal">Totale Bambino 8-12: €159,25</div>
            </div>

            <div class="total">
                ✅ TOTALE CORRETTO: €438,00 + €146,30 + €159,25 = €743,55
            </div>
        </div>

        <div class="section">
            <h2>❌ Discrepanza Rilevata</h2>
            <div class="error">
                <p><strong>Sistema mostra:</strong> €783,55</p>
                <p><strong>Calcolo corretto:</strong> €743,55</p>
                <p><strong>Differenza:</strong> €40,00</p>
            </div>
            
            <div class="warning">
                <h3>🔍 Possibili Cause della Differenza di €40:</h3>
                <ul>
                    <li>Il supplemento pacchetto potrebbe essere calcolato per 2 notti invece di 1</li>
                    <li>Potrebbe esserci un doppio conteggio del supplemento notte extra</li>
                    <li>Il supplemento base potrebbe essere applicato anche alle notti extra</li>
                </ul>
            </div>
        </div>

        <?php
        // Analizza il codice JavaScript
        echo '<div class="section">';
        echo '<h2>🔧 Analisi Codice Frontend</h2>';
        echo '<p>Verifichiamo il file <code>frontend-scripts.js</code> per vedere come vengono calcolati i prezzi...</p>';
        
        // Cerca la funzione di calcolo prezzi
        $js_file = BTR_PLUGIN_DIR . 'assets/js/frontend-scripts.js';
        if (file_exists($js_file)) {
            $js_content = file_get_contents($js_file);
            
            // Cerca la sezione di calcolo prezzi
            if (preg_match('/calculateDynamicSummary.*?function/s', $js_content, $matches)) {
                echo '<div class="code">Funzione calculateDynamicSummary trovata...</div>';
            }
            
            // Cerca come vengono calcolati i supplementi
            if (preg_match('/supplemento.*?\*/s', $js_content, $matches)) {
                echo '<div class="code">Logica supplementi trovata...</div>';
            }
        }
        echo '</div>';
        ?>

        <div class="section">
            <h2>📝 Script di Debug</h2>
            <p>Per verificare il calcolo nel frontend, apri la console JavaScript e esegui:</p>
            <div class="code">
// Mostra tutti i prezzi e calcoli
console.log('[DEBUG] Prezzi base:', {
    adulti: 159,
    bambino_3_8: 111.30,
    bambino_8_12: 119.25
});

console.log('[DEBUG] Supplementi:', {
    base: 10,
    notte_extra_adulti: 40,
    notte_extra_bambino_3_8: 15,
    notte_extra_bambino_8_12: 20
});

// Verifica il numero di notti
console.log('[DEBUG] Notti pacchetto base:', window.btrPackageNights || 1);
console.log('[DEBUG] Notti extra:', window.btrExtraNightsCount || 1);
            </div>
        </div>

        <div class="section">
            <h2>🛠️ Prossimi Passi</h2>
            <ol>
                <li>Verificare nel file <code>frontend-scripts.js</code> come viene calcolato il supplemento base</li>
                <li>Controllare se il supplemento viene moltiplicato per il numero totale di notti</li>
                <li>Verificare se ci sono duplicazioni nel calcolo</li>
            </ol>
        </div>
    </div>
</body>
</html>