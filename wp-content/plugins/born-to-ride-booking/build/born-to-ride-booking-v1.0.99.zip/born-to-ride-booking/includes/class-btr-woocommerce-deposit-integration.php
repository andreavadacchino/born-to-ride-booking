<?php
/**
 * Integrazione WooCommerce per sistema caparra/saldo
 * 
 * Gestisce l'integrazione tra il sistema di caparra BTR e WooCommerce checkout
 * 
 * @package BornToRideBooking
 * @since 1.0.98
 */

if (!defined('ABSPATH')) {
    exit;
}

class BTR_WooCommerce_Deposit_Integration {
    
    /**
     * Instance singleton
     */
    private static $instance = null;
    
    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        // Hook checkout process
        add_action('woocommerce_checkout_init', [$this, 'init_deposit_checkout']);
        add_filter('woocommerce_checkout_fields', [$this, 'add_deposit_fields'], 20);
        
        // Modifica calcolo totali per caparra
        add_action('woocommerce_cart_calculate_fees', [$this, 'calculate_deposit_fee']);
        add_filter('woocommerce_cart_totals_order_total_html', [$this, 'modify_order_total_display'], 20);
        
        // Gestione creazione ordine
        add_action('woocommerce_checkout_create_order', [$this, 'save_deposit_meta'], 10, 2);
        add_action('woocommerce_checkout_order_processed', [$this, 'process_deposit_order'], 10, 3);
        
        // Stati ordine custom
        add_action('init', [$this, 'register_deposit_order_statuses']);
        add_filter('wc_order_statuses', [$this, 'add_deposit_order_statuses']);
        
        // Email custom
        add_filter('woocommerce_email_classes', [$this, 'add_deposit_emails']);
        
        // Admin
        add_filter('woocommerce_admin_order_preview_get_order_details', [$this, 'add_deposit_info_to_preview'], 10, 2);
        add_action('woocommerce_admin_order_data_after_order_details', [$this, 'display_deposit_info_in_admin']);
        
        // Frontend
        add_action('woocommerce_order_details_after_order_table', [$this, 'display_deposit_info_frontend']);
        add_action('woocommerce_thankyou', [$this, 'display_deposit_thank_you'], 5);
        
        // AJAX handlers
        add_action('wp_ajax_btr_toggle_deposit_mode', [$this, 'ajax_toggle_deposit_mode']);
        add_action('wp_ajax_nopriv_btr_toggle_deposit_mode', [$this, 'ajax_toggle_deposit_mode']);
        
        // Script e stili
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
    }
    
    /**
     * Inizializza checkout per caparra
     */
    public function init_deposit_checkout($checkout) {
        // Verifica se siamo in modalità caparra
        $payment_type = WC()->session->get('btr_payment_type');
        $payment_plan = WC()->session->get('btr_payment_plan');
        
        if ($payment_type === 'deposit' || $payment_plan === 'deposit_balance') {
            // Attiva modalità caparra
            WC()->session->set('btr_deposit_mode', true);
            
            // Recupera percentuale caparra
            $preventivo_id = WC()->session->get('btr_preventivo_id');
            if ($preventivo_id) {
                $deposit_percentage = get_post_meta($preventivo_id, '_btr_deposit_percentage', true);
                if (!$deposit_percentage) {
                    $deposit_percentage = BTR_Deposit_Balance::DEFAULT_DEPOSIT_PERCENTAGE;
                }
                WC()->session->set('btr_deposit_percentage', $deposit_percentage);
            }
        }
    }
    
    /**
     * Aggiunge campi checkout per caparra
     */
    public function add_deposit_fields($fields) {
        $deposit_mode = WC()->session->get('btr_deposit_mode');
        
        if ($deposit_mode) {
            // Aggiungi campo nascosto per tracciare modalità caparra
            $fields['billing']['btr_payment_mode'] = [
                'type' => 'hidden',
                'default' => 'deposit',
                'class' => ['btr-deposit-field']
            ];
            
            // Aggiungi informazioni visibili sulla caparra
            $deposit_percentage = WC()->session->get('btr_deposit_percentage', 30);
            $cart_total = WC()->cart->get_total('raw');
            $deposit_amount = $cart_total * ($deposit_percentage / 100);
            $balance_amount = $cart_total - $deposit_amount;
            
            // Campo informativo (non input)
            $fields['billing']['btr_deposit_info'] = [
                'type' => 'info',
                'label' => __('Modalità Pagamento', 'born-to-ride-booking'),
                'description' => sprintf(
                    __('Stai pagando una caparra del %d%% (€%s). Il saldo di €%s sarà richiesto successivamente.', 'born-to-ride-booking'),
                    $deposit_percentage,
                    number_format($deposit_amount, 2, ',', '.'),
                    number_format($balance_amount, 2, ',', '.')
                ),
                'class' => ['btr-deposit-info', 'form-row-wide'],
                'priority' => 1
            ];
        }
        
        return $fields;
    }
    
    /**
     * Calcola fee negativa per ridurre totale a caparra
     */
    public function calculate_deposit_fee() {
        if (!WC()->session->get('btr_deposit_mode')) {
            return;
        }
        
        $deposit_percentage = WC()->session->get('btr_deposit_percentage', 30);
        $cart_total = WC()->cart->get_subtotal() + WC()->cart->get_cart_contents_tax();
        
        // Aggiungi anche shipping e altre fees
        $shipping_total = WC()->cart->get_shipping_total() + WC()->cart->get_shipping_tax();
        $fees_total = 0;
        foreach (WC()->cart->get_fees() as $fee) {
            $fees_total += $fee->amount + $fee->tax;
        }
        
        $full_total = $cart_total + $shipping_total + $fees_total;
        $deposit_amount = $full_total * ($deposit_percentage / 100);
        $discount_amount = $full_total - $deposit_amount;
        
        // Rimuovi fee esistente se presente
        $fees = WC()->cart->get_fees();
        foreach ($fees as $key => $fee) {
            if ($fee->id === 'btr-deposit-adjustment') {
                unset($fees[$key]);
            }
        }
        
        // Aggiungi fee negativa per ridurre totale
        if ($discount_amount > 0) {
            WC()->cart->add_fee(
                sprintf(__('Saldo da pagare successivamente (-%d%%)', 'born-to-ride-booking'), 100 - $deposit_percentage),
                -$discount_amount,
                false,
                ''
            );
            
            // Salva importi in sessione per riferimento
            WC()->session->set('btr_deposit_amount', $deposit_amount);
            WC()->session->set('btr_balance_amount', $discount_amount);
            WC()->session->set('btr_full_amount', $full_total);
        }
    }
    
    /**
     * Modifica display totale ordine
     */
    public function modify_order_total_display($html) {
        if (!WC()->session->get('btr_deposit_mode')) {
            return $html;
        }
        
        $deposit_amount = WC()->session->get('btr_deposit_amount');
        $balance_amount = WC()->session->get('btr_balance_amount');
        $full_amount = WC()->session->get('btr_full_amount');
        
        if ($deposit_amount && $balance_amount) {
            $html = '<strong>' . wc_price($deposit_amount) . '</strong>';
            $html .= '<div class="btr-deposit-breakdown">';
            $html .= '<small class="btr-full-total">' . 
                     sprintf(__('Totale viaggio: %s', 'born-to-ride-booking'), wc_price($full_amount)) . 
                     '</small><br>';
            $html .= '<small class="btr-deposit-now">' . 
                     sprintf(__('Caparra ora: %s', 'born-to-ride-booking'), wc_price($deposit_amount)) . 
                     '</small><br>';
            $html .= '<small class="btr-balance-later">' . 
                     sprintf(__('Saldo successivo: %s', 'born-to-ride-booking'), wc_price($balance_amount)) . 
                     '</small>';
            $html .= '</div>';
        }
        
        return $html;
    }
    
    /**
     * Salva meta dati caparra nell'ordine
     */
    public function save_deposit_meta($order, $data) {
        if (!WC()->session->get('btr_deposit_mode')) {
            return;
        }
        
        // Salva tutti i meta dati caparra
        $order->update_meta_data('_btr_payment_mode', 'deposit');
        $order->update_meta_data('_btr_deposit_percentage', WC()->session->get('btr_deposit_percentage'));
        $order->update_meta_data('_btr_deposit_amount', WC()->session->get('btr_deposit_amount'));
        $order->update_meta_data('_btr_balance_amount', WC()->session->get('btr_balance_amount'));
        $order->update_meta_data('_btr_full_amount', WC()->session->get('btr_full_amount'));
        
        // Collega al preventivo
        $preventivo_id = WC()->session->get('btr_preventivo_id');
        if ($preventivo_id) {
            $order->update_meta_data('_btr_preventivo_id', $preventivo_id);
            $order->update_meta_data('_btr_payment_plan_type', 'deposit_balance');
            
            // Salva stato pagamento nel preventivo
            update_post_meta($preventivo_id, '_btr_deposit_order_id', $order->get_id());
            update_post_meta($preventivo_id, '_btr_deposit_status', 'pending');
        }
        
        // Aggiungi nota all'ordine
        $order->add_order_note(sprintf(
            __('Ordine caparra %d%% di %s. Saldo di %s da pagare.', 'born-to-ride-booking'),
            WC()->session->get('btr_deposit_percentage'),
            wc_price(WC()->session->get('btr_full_amount')),
            wc_price(WC()->session->get('btr_balance_amount'))
        ));
    }
    
    /**
     * Processa ordine caparra
     */
    public function process_deposit_order($order_id, $posted_data, $order) {
        if ($order->get_meta('_btr_payment_mode') !== 'deposit') {
            return;
        }
        
        // Imposta stato ordine custom
        $order->set_status('wc-deposit-paid');
        $order->save();
        
        // Aggiorna preventivo
        $preventivo_id = $order->get_meta('_btr_preventivo_id');
        if ($preventivo_id) {
            update_post_meta($preventivo_id, '_btr_deposit_status', 'paid');
            update_post_meta($preventivo_id, '_btr_deposit_paid_date', current_time('mysql'));
            
            // Trigger per generare link saldo
            do_action('btr_deposit_paid', $preventivo_id, $order_id);
        }
        
        // Pulisci sessione
        WC()->session->__unset('btr_deposit_mode');
        WC()->session->__unset('btr_deposit_percentage');
        WC()->session->__unset('btr_deposit_amount');
        WC()->session->__unset('btr_balance_amount');
        WC()->session->__unset('btr_full_amount');
    }
    
    /**
     * Registra stati ordine custom
     */
    public function register_deposit_order_statuses() {
        // Stato: Caparra Pagata
        register_post_status('wc-deposit-paid', [
            'label' => __('Caparra Pagata', 'born-to-ride-booking'),
            'public' => true,
            'show_in_admin_status_list' => true,
            'show_in_admin_all_list' => true,
            'exclude_from_search' => false,
            'label_count' => _n_noop(
                'Caparra Pagata <span class="count">(%s)</span>',
                'Caparre Pagate <span class="count">(%s)</span>',
                'born-to-ride-booking'
            )
        ]);
        
        // Stato: In Attesa Saldo
        register_post_status('wc-awaiting-balance', [
            'label' => __('In Attesa Saldo', 'born-to-ride-booking'),
            'public' => true,
            'show_in_admin_status_list' => true,
            'show_in_admin_all_list' => true,
            'exclude_from_search' => false,
            'label_count' => _n_noop(
                'In Attesa Saldo <span class="count">(%s)</span>',
                'In Attesa Saldo <span class="count">(%s)</span>',
                'born-to-ride-booking'
            )
        ]);
        
        // Stato: Pagamento Completo
        register_post_status('wc-fully-paid', [
            'label' => __('Pagamento Completo', 'born-to-ride-booking'),
            'public' => true,
            'show_in_admin_status_list' => true,
            'show_in_admin_all_list' => true,
            'exclude_from_search' => false,
            'label_count' => _n_noop(
                'Pagamento Completo <span class="count">(%s)</span>',
                'Pagamenti Completi <span class="count">(%s)</span>',
                'born-to-ride-booking'
            )
        ]);
    }
    
    /**
     * Aggiunge stati al dropdown WooCommerce
     */
    public function add_deposit_order_statuses($order_statuses) {
        $order_statuses['wc-deposit-paid'] = __('Caparra Pagata', 'born-to-ride-booking');
        $order_statuses['wc-awaiting-balance'] = __('In Attesa Saldo', 'born-to-ride-booking');
        $order_statuses['wc-fully-paid'] = __('Pagamento Completo', 'born-to-ride-booking');
        
        return $order_statuses;
    }
    
    /**
     * Display info caparra in admin
     */
    public function display_deposit_info_in_admin($order) {
        $payment_mode = $order->get_meta('_btr_payment_mode');
        
        if ($payment_mode !== 'deposit') {
            return;
        }
        
        $deposit_percentage = $order->get_meta('_btr_deposit_percentage');
        $deposit_amount = $order->get_meta('_btr_deposit_amount');
        $balance_amount = $order->get_meta('_btr_balance_amount');
        $full_amount = $order->get_meta('_btr_full_amount');
        ?>
        <div class="btr-deposit-info-admin">
            <h3><?php esc_html_e('Informazioni Caparra', 'born-to-ride-booking'); ?></h3>
            <table class="btr-deposit-table">
                <tr>
                    <td><strong><?php esc_html_e('Modalità:', 'born-to-ride-booking'); ?></strong></td>
                    <td><?php esc_html_e('Caparra + Saldo', 'born-to-ride-booking'); ?></td>
                </tr>
                <tr>
                    <td><strong><?php esc_html_e('Percentuale Caparra:', 'born-to-ride-booking'); ?></strong></td>
                    <td><?php echo esc_html($deposit_percentage); ?>%</td>
                </tr>
                <tr>
                    <td><strong><?php esc_html_e('Totale Viaggio:', 'born-to-ride-booking'); ?></strong></td>
                    <td><?php echo wc_price($full_amount); ?></td>
                </tr>
                <tr>
                    <td><strong><?php esc_html_e('Caparra Pagata:', 'born-to-ride-booking'); ?></strong></td>
                    <td><?php echo wc_price($deposit_amount); ?></td>
                </tr>
                <tr>
                    <td><strong><?php esc_html_e('Saldo Rimanente:', 'born-to-ride-booking'); ?></strong></td>
                    <td><?php echo wc_price($balance_amount); ?></td>
                </tr>
            </table>
            
            <?php
            // Mostra pulsante per generare link saldo se caparra pagata
            if ($order->has_status(['deposit-paid', 'processing', 'completed'])) {
                $preventivo_id = $order->get_meta('_btr_preventivo_id');
                $balance_order_id = get_post_meta($preventivo_id, '_btr_balance_order_id', true);
                
                if (!$balance_order_id && $preventivo_id) {
                    ?>
                    <div class="btr-generate-balance-link">
                        <button type="button" class="button button-primary" 
                                data-preventivo-id="<?php echo esc_attr($preventivo_id); ?>"
                                data-order-id="<?php echo esc_attr($order->get_id()); ?>"
                                id="btr-generate-balance-btn">
                            <?php esc_html_e('Genera Link Pagamento Saldo', 'born-to-ride-booking'); ?>
                        </button>
                    </div>
                    <?php
                }
            }
            ?>
        </div>
        
        <style>
        .btr-deposit-info-admin {
            margin-top: 20px;
            padding: 15px;
            background: #f8f9fa;
            border: 1px solid #e0e0e0;
            border-radius: 4px;
        }
        
        .btr-deposit-info-admin h3 {
            margin-top: 0;
            margin-bottom: 15px;
            color: #0097c5;
        }
        
        .btr-deposit-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .btr-deposit-table td {
            padding: 8px 0;
            border-bottom: 1px solid #eee;
        }
        
        .btr-deposit-table tr:last-child td {
            border-bottom: none;
        }
        
        .btr-generate-balance-link {
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #e0e0e0;
        }
        </style>
        <?php
    }
    
    /**
     * Display thank you message per caparra
     */
    public function display_deposit_thank_you($order_id) {
        $order = wc_get_order($order_id);
        if (!$order || $order->get_meta('_btr_payment_mode') !== 'deposit') {
            return;
        }
        
        $balance_amount = $order->get_meta('_btr_balance_amount');
        ?>
        <div class="btr-deposit-thank-you">
            <div class="btr-deposit-notice">
                <h2><?php esc_html_e('Caparra Confermata!', 'born-to-ride-booking'); ?></h2>
                <p><?php esc_html_e('La tua caparra è stata ricevuta con successo.', 'born-to-ride-booking'); ?></p>
                
                <div class="btr-balance-info">
                    <p><strong><?php esc_html_e('Importante:', 'born-to-ride-booking'); ?></strong></p>
                    <p><?php 
                        printf(
                            __('Il saldo di %s sarà richiesto successivamente. Riceverai un\'email con le istruzioni per il pagamento.', 'born-to-ride-booking'),
                            wc_price($balance_amount)
                        ); 
                    ?></p>
                </div>
            </div>
        </div>
        
        <style>
        .btr-deposit-thank-you {
            margin: 30px 0;
        }
        
        .btr-deposit-notice {
            background: #e3f2fd;
            border: 1px solid #0097c5;
            border-radius: 8px;
            padding: 30px;
            text-align: center;
        }
        
        .btr-deposit-notice h2 {
            color: #0097c5;
            margin-bottom: 15px;
        }
        
        .btr-balance-info {
            background: #fff;
            padding: 20px;
            border-radius: 4px;
            margin-top: 20px;
            text-align: left;
        }
        
        .btr-balance-info p {
            margin: 10px 0;
        }
        </style>
        <?php
    }
    
    /**
     * Aggiunge email custom per caparra
     */
    public function add_deposit_emails($email_classes) {
        // TODO: Implementare email custom per caparra se necessario
        // Per ora restituisce le classi email senza modifiche
        
        // Esempio di come aggiungere email custom:
        // $email_classes['WC_Email_Deposit_Paid'] = include 'emails/class-wc-email-deposit-paid.php';
        // $email_classes['WC_Email_Balance_Reminder'] = include 'emails/class-wc-email-balance-reminder.php';
        
        return $email_classes;
    }
    
    /**
     * Enqueue scripts
     */
    public function enqueue_scripts() {
        if (!is_checkout()) {
            return;
        }
        
        wp_enqueue_script(
            'btr-deposit-checkout',
            BTR_PLUGIN_URL . 'assets/js/deposit-checkout.js',
            ['jquery'],
            BTR_VERSION,
            true
        );
        
        wp_localize_script('btr-deposit-checkout', 'btr_deposit_checkout', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('btr_deposit_checkout'),
            'strings' => [
                'toggle_deposit' => __('Paga solo la caparra', 'born-to-ride-booking'),
                'toggle_full' => __('Paga importo completo', 'born-to-ride-booking'),
                'deposit_info' => __('Pagherai ora solo la caparra. Il saldo sarà richiesto successivamente.', 'born-to-ride-booking')
            ]
        ]);
        
        wp_add_inline_style('woocommerce-layout', '
            .btr-deposit-info {
                background: #e3f2fd;
                padding: 15px;
                border-radius: 4px;
                margin-bottom: 20px;
                border: 1px solid #0097c5;
            }
            
            .btr-deposit-info .description {
                margin: 0;
                color: #0c5460;
                font-weight: 500;
            }
            
            .btr-deposit-breakdown {
                margin-top: 10px;
                padding-top: 10px;
                border-top: 1px solid #e0e0e0;
            }
            
            .btr-deposit-breakdown small {
                display: block;
                margin: 5px 0;
                color: #666;
            }
            
            .btr-deposit-breakdown .btr-deposit-now {
                color: #0097c5;
                font-weight: 600;
            }
        ');
    }
    
    /**
     * AJAX toggle deposit mode
     */
    public function ajax_toggle_deposit_mode() {
        check_ajax_referer('btr_deposit_checkout', 'nonce');
        
        $enable = isset($_POST['enable']) ? filter_var($_POST['enable'], FILTER_VALIDATE_BOOLEAN) : false;
        
        if ($enable) {
            WC()->session->set('btr_deposit_mode', true);
        } else {
            WC()->session->__unset('btr_deposit_mode');
        }
        
        // Forza ricalcolo carrello
        WC()->cart->calculate_totals();
        
        wp_send_json_success([
            'deposit_mode' => WC()->session->get('btr_deposit_mode'),
            'cart_total' => WC()->cart->get_total(),
            'message' => $enable ? 
                __('Modalità caparra attivata', 'born-to-ride-booking') : 
                __('Modalità pagamento completo attivata', 'born-to-ride-booking')
        ]);
    }
}

// Inizializza
BTR_WooCommerce_Deposit_Integration::get_instance();