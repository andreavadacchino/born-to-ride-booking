<?php
/**
 * Extended Payment Plans functionality
 * 
 * Estende BTR_Payment_Plans per integrare con la tabella btr_order_shares
 * e gestire pagamenti di gruppo e depositi in modo più completo
 * 
 * @package BornToRideBooking
 * @since 1.1.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Assicura che la classe base sia caricata
if (!class_exists('BTR_Payment_Plans')) {
    require_once BTR_PLUGIN_DIR . 'includes/class-btr-payment-plans.php';
}

// Include Database Manager
if (!class_exists('BTR_Database_Manager')) {
    require_once BTR_PLUGIN_DIR . 'includes/class-btr-database-manager.php';
}

/**
 * Class BTR_Payment_Plans_Extended
 * 
 * Estende la funzionalità di payment plans con integrazione btr_order_shares
 */
class BTR_Payment_Plans_Extended extends BTR_Payment_Plans {
    
    /**
     * Database manager instance
     * @var BTR_Database_Manager
     */
    private $db_manager;
    
    /**
     * Singleton instance
     * @var BTR_Payment_Plans_Extended
     */
    private static $extended_instance = null;
    
    /**
     * Get extended singleton instance
     * @return BTR_Payment_Plans_Extended
     */
    public static function get_extended_instance() {
        if (null === self::$extended_instance) {
            self::$extended_instance = new self();
        }
        return self::$extended_instance;
    }
    
    /**
     * Constructor
     */
    protected function __construct() {
        parent::__construct();
        $this->db_manager = BTR_Database_Manager::get_instance();
        $this->init_extended_hooks();
    }
    
    /**
     * Initialize extended hooks
     */
    private function init_extended_hooks() {
        // Override parent's group payment creation
        remove_action('btr_after_create_payment_plan', [$this, 'generate_group_payment_links'], 10);
        add_action('btr_after_create_payment_plan', [$this, 'handle_payment_plan_creation'], 10, 3);
        
        // Hook per sincronizzazione stati
        add_action('btr_payment_status_changed', [$this, 'sync_payment_status'], 10, 3);
        
        // Hook per reminder
        add_action('btr_hourly_cron', [$this, 'process_payment_reminders']);
    }
    
    /**
     * Create payment shares for group payment
     * Enhanced with improved validation, atomic transactions, and audit trail
     * 
     * @param int $order_id WooCommerce order ID
     * @param array $participants_data Array of participant data
     * @param array $options Additional options for share creation
     * @return array|WP_Error Array of share IDs or error
     */
    public function create_group_payment_shares($order_id, $participants_data, $options = []) {
        // 1. Enhanced input validation
        $validation_result = $this->validate_group_payment_input($order_id, $participants_data, $options);
        if (is_wp_error($validation_result)) {
            return $validation_result;
        }
        
        $order = wc_get_order($order_id);
        $order_total = floatval($order->get_total());
        
        // 2. Advanced share calculation with distribution algorithms
        $calculated_shares = $this->calculate_payment_shares($participants_data, $order_total, $options);
        if (is_wp_error($calculated_shares)) {
            return $calculated_shares;
        }
        
        // 3. Comprehensive total validation
        $validation_result = $this->validate_share_totals($calculated_shares, $order_total);
        if (is_wp_error($validation_result)) {
            return $validation_result;
        }
        
        $shares_created = [];
        $audit_data = [
            'operation' => 'create_group_payment_shares',
            'order_id' => $order_id,
            'order_total' => $order_total,
            'participant_count' => count($calculated_shares),
            'created_at' => current_time('mysql'),
            'created_by' => get_current_user_id()
        ];
        
        // 4. Enhanced atomic transaction with comprehensive error handling
        $transaction_result = $this->db_manager->transaction(function() use (
            $order_id, $calculated_shares, &$shares_created, &$audit_data, $options
        ) {
            $payment_batch_id = wp_generate_uuid4();
            $audit_data['batch_id'] = $payment_batch_id;
            
            foreach ($calculated_shares as $share_data) {
                // Generate secure payment credentials
                $token = $this->generate_secure_payment_token();
                $payment_hash = $this->generate_payment_hash($order_id, $share_data['participant_email'], $token);
                $payment_link = $this->generate_payment_link($order_id, $payment_hash);
                
                // Enhanced share data structure
                $enhanced_share_data = [
                    'order_id' => $order_id,
                    'payment_batch_id' => $payment_batch_id,
                    'participant_id' => $share_data['participant_id'] ?? 0,
                    'participant_name' => sanitize_text_field($share_data['participant_name']),
                    'participant_email' => sanitize_email($share_data['participant_email']),
                    'participant_phone' => isset($share_data['participant_phone']) ? sanitize_text_field($share_data['participant_phone']) : null,
                    'amount_assigned' => $share_data['calculated_amount'],
                    'original_amount' => $share_data['original_amount'] ?? $share_data['calculated_amount'],
                    'share_percentage' => $share_data['share_percentage'],
                    'calculation_method' => $share_data['calculation_method'],
                    'payment_token' => $token,
                    'payment_hash' => $payment_hash,
                    'payment_link' => esc_url_raw($payment_link),
                    'payment_status' => 'pending',
                    'payment_type' => 'group_share',
                    'currency' => $order->get_currency(),
                    'expires_at' => date('Y-m-d H:i:s', strtotime('+72 hours')),
                    'next_reminder_at' => date('Y-m-d H:i:s', strtotime('+24 hours')),
                    'metadata' => json_encode([
                        'creation_options' => $options,
                        'calculation_details' => $share_data['calculation_details'] ?? [],
                        'batch_info' => ['batch_id' => $payment_batch_id, 'batch_size' => count($calculated_shares)]
                    ]),
                    'created_at' => current_time('mysql'),
                    'updated_at' => current_time('mysql')
                ];
                
                // Create share with enhanced error handling
                $share_id = $this->db_manager->create($enhanced_share_data);
                
                if (is_wp_error($share_id)) {
                    $audit_data['errors'][] = [
                        'participant' => $share_data['participant_name'],
                        'error' => $share_id->get_error_message(),
                        'timestamp' => current_time('mysql')
                    ];
                    throw new Exception(sprintf(
                        __('Errore creazione quota per %s: %s', 'born-to-ride-booking'),
                        $share_data['participant_name'],
                        $share_id->get_error_message()
                    ));
                }
                
                $shares_created[] = [
                    'share_id' => $share_id,
                    'participant_email' => $share_data['participant_email'],
                    'amount' => $share_data['calculated_amount'],
                    'payment_link' => $payment_link,
                    'payment_hash' => $payment_hash
                ];
                
                $audit_data['shares_created'][] = [
                    'share_id' => $share_id,
                    'participant_name' => $share_data['participant_name'],
                    'amount' => $share_data['calculated_amount'],
                    'percentage' => $share_data['share_percentage']
                ];
            }
            
            return true;
        });
        
        if (is_wp_error($transaction_result)) {
            $audit_data['status'] = 'failed';
            $audit_data['error'] = $transaction_result->get_error_message();
            $this->log_audit_trail($audit_data);
            return $transaction_result;
        }
        
        // 5. Enhanced order metadata and audit trail
        $this->update_order_metadata($order, $shares_created, $audit_data);
        
        // 6. Automatic email trigger system with enhanced error handling
        $email_results = $this->trigger_payment_emails($shares_created, $order);
        $audit_data['email_results'] = $email_results;
        
        // Log successful completion
        $audit_data['status'] = 'completed';
        $audit_data['completed_at'] = current_time('mysql');
        $this->log_audit_trail($audit_data);
        
        // Enhanced logging
        btr_debug_log(sprintf(
            'Successfully created %d payment shares for order %d (batch: %s, total: %s %s)',
            count($shares_created),
            $order_id,
            $audit_data['batch_id'],
            number_format($order_total, 2),
            $order->get_currency()
        ));
        
        return array_column($shares_created, 'share_id');
    }
    
    /**
     * Enhanced share calculation with multiple distribution algorithms
     * 
     * @param array $participants_data Raw participant data
     * @param float $order_total Order total amount
     * @param array $options Calculation options
     * @return array|WP_Error Calculated shares or error
     */
    private function calculate_payment_shares($participants_data, $order_total, $options = []) {
        $distribution_method = $options['distribution_method'] ?? 'equal';
        $calculated_shares = [];
        
        switch ($distribution_method) {
            case 'equal':
                $calculated_shares = $this->calculate_equal_shares($participants_data, $order_total);
                break;
                
            case 'custom':
                $calculated_shares = $this->calculate_custom_shares($participants_data, $order_total);
                break;
                
            case 'percentage':
                $calculated_shares = $this->calculate_percentage_shares($participants_data, $order_total);
                break;
                
            case 'weighted':
                $calculated_shares = $this->calculate_weighted_shares($participants_data, $order_total, $options);
                break;
                
            default:
                return new WP_Error('invalid_distribution_method', 
                    sprintf(__('Metodo di distribuzione non valido: %s', 'born-to-ride-booking'), $distribution_method)
                );
        }
        
        if (is_wp_error($calculated_shares)) {
            return $calculated_shares;
        }
        
        // Apply rounding and adjustment to ensure exact total match
        return $this->adjust_shares_for_exact_total($calculated_shares, $order_total);
    }
    
    /**
     * Calculate equal distribution shares
     */
    private function calculate_equal_shares($participants_data, $order_total) {
        $participant_count = count($participants_data);
        $share_amount = $order_total / $participant_count;
        $shares = [];
        
        foreach ($participants_data as $index => $participant) {
            $shares[] = [
                'participant_id' => $participant['id'] ?? 0,
                'participant_name' => $participant['name'],
                'participant_email' => $participant['email'],
                'participant_phone' => $participant['phone'] ?? null,
                'calculated_amount' => $share_amount,
                'share_percentage' => round(100 / $participant_count, 4),
                'calculation_method' => 'equal',
                'calculation_details' => [
                    'base_amount' => $share_amount,
                    'participant_count' => $participant_count,
                    'order_total' => $order_total
                ]
            ];
        }
        
        return $shares;
    }
    
    /**
     * Calculate custom amount shares
     */
    private function calculate_custom_shares($participants_data, $order_total) {
        $shares = [];
        $total_assigned = 0;
        
        foreach ($participants_data as $participant) {
            if (!isset($participant['amount']) || !is_numeric($participant['amount'])) {
                return new WP_Error('missing_custom_amount', 
                    sprintf(__('Importo personalizzato mancante per %s', 'born-to-ride-booking'), $participant['name'])
                );
            }
            
            $amount = floatval($participant['amount']);
            $total_assigned += $amount;
            
            $shares[] = [
                'participant_id' => $participant['id'] ?? 0,
                'participant_name' => $participant['name'],
                'participant_email' => $participant['email'],
                'participant_phone' => $participant['phone'] ?? null,
                'calculated_amount' => $amount,
                'original_amount' => $amount,
                'share_percentage' => round(($amount / $order_total) * 100, 4),
                'calculation_method' => 'custom',
                'calculation_details' => [
                    'custom_amount' => $amount,
                    'order_total' => $order_total
                ]
            ];
        }
        
        // Validate that custom amounts don't exceed order total
        if (abs($total_assigned - $order_total) > 0.01) {
            return new WP_Error('custom_amount_mismatch', 
                sprintf(
                    __('Totale importi personalizzati (€%s) non corrisponde al totale ordine (€%s)', 'born-to-ride-booking'),
                    number_format($total_assigned, 2),
                    number_format($order_total, 2)
                )
            );
        }
        
        return $shares;
    }
    
    /**
     * Calculate percentage-based shares
     */
    private function calculate_percentage_shares($participants_data, $order_total) {
        $shares = [];
        $total_percentage = 0;
        
        foreach ($participants_data as $participant) {
            if (!isset($participant['percentage']) || !is_numeric($participant['percentage'])) {
                return new WP_Error('missing_percentage', 
                    sprintf(__('Percentuale mancante per %s', 'born-to-ride-booking'), $participant['name'])
                );
            }
            
            $percentage = floatval($participant['percentage']);
            $total_percentage += $percentage;
            $amount = ($percentage / 100) * $order_total;
            
            $shares[] = [
                'participant_id' => $participant['id'] ?? 0,
                'participant_name' => $participant['name'],
                'participant_email' => $participant['email'],
                'participant_phone' => $participant['phone'] ?? null,
                'calculated_amount' => $amount,
                'share_percentage' => $percentage,
                'calculation_method' => 'percentage',
                'calculation_details' => [
                    'assigned_percentage' => $percentage,
                    'calculated_amount' => $amount,
                    'order_total' => $order_total
                ]
            ];
        }
        
        // Validate percentages sum to 100
        if (abs($total_percentage - 100) > 0.01) {
            return new WP_Error('percentage_sum_invalid', 
                sprintf(
                    __('Totale percentuali (%s%%) deve essere 100%%', 'born-to-ride-booking'),
                    number_format($total_percentage, 2)
                )
            );
        }
        
        return $shares;
    }
    
    /**
     * Calculate weighted shares based on custom weights
     */
    private function calculate_weighted_shares($participants_data, $order_total, $options) {
        $weight_field = $options['weight_field'] ?? 'weight';
        $shares = [];
        $total_weight = 0;
        
        // Calculate total weight
        foreach ($participants_data as $participant) {
            if (!isset($participant[$weight_field]) || !is_numeric($participant[$weight_field])) {
                return new WP_Error('missing_weight', 
                    sprintf(__('Peso mancante per %s', 'born-to-ride-booking'), $participant['name'])
                );
            }
            $total_weight += floatval($participant[$weight_field]);
        }
        
        if ($total_weight <= 0) {
            return new WP_Error('invalid_total_weight', __('Peso totale deve essere maggiore di zero', 'born-to-ride-booking'));
        }
        
        // Calculate weighted shares
        foreach ($participants_data as $participant) {
            $weight = floatval($participant[$weight_field]);
            $percentage = ($weight / $total_weight) * 100;
            $amount = ($weight / $total_weight) * $order_total;
            
            $shares[] = [
                'participant_id' => $participant['id'] ?? 0,
                'participant_name' => $participant['name'],
                'participant_email' => $participant['email'],
                'participant_phone' => $participant['phone'] ?? null,
                'calculated_amount' => $amount,
                'share_percentage' => round($percentage, 4),
                'calculation_method' => 'weighted',
                'calculation_details' => [
                    'weight' => $weight,
                    'total_weight' => $total_weight,
                    'calculated_percentage' => $percentage,
                    'order_total' => $order_total
                ]
            ];
        }
        
        return $shares;
    }
    
    /**
     * Adjust shares to ensure exact total match with order amount
     */
    private function adjust_shares_for_exact_total($shares, $order_total) {
        $calculated_total = array_sum(array_column($shares, 'calculated_amount'));
        $difference = $order_total - $calculated_total;
        
        // If difference is negligible (< 1 cent), adjust the largest share
        if (abs($difference) > 0 && abs($difference) < 0.01) {
            // Find the share with the largest amount to adjust
            $max_index = 0;
            $max_amount = 0;
            
            foreach ($shares as $index => $share) {
                if ($share['calculated_amount'] > $max_amount) {
                    $max_amount = $share['calculated_amount'];
                    $max_index = $index;
                }
            }
            
            $shares[$max_index]['calculated_amount'] += $difference;
            $shares[$max_index]['calculation_details']['rounding_adjustment'] = $difference;
        }
        
        return $shares;
    }
    
    /**
     * Generate secure payment token
     * 
     * @return string
     */
    private function generate_secure_payment_token() {
        return bin2hex(random_bytes(32));
    }
    
    /**
     * Generate payment hash for secure identification
     * 
     * @param int $order_id
     * @param string $email
     * @param string $token
     * @return string
     */
    private function generate_payment_hash($order_id, $email, $token) {
        $data = $order_id . '|' . $email . '|' . $token . '|' . wp_salt('auth');
        return hash('sha256', $data);
    }
    
    /**
     * Generate payment link
     * 
     * @param int $order_id
     * @param string $token
     * @return string
     */
    private function generate_payment_link($order_id, $token) {
        return add_query_arg([
            'btr_payment' => 'individual',
            'order' => $order_id,
            'token' => $token
        ], home_url('/pagamento-individuale/'));
    }
    
    /**
     * Send payment link email
     * 
     * @param string $email
     * @param string $payment_link
     * @param array $participant_data
     * @return bool
     */
    private function send_payment_link_email($email, $payment_link, $participant_data) {
        // Usa il sistema email esistente se disponibile
        if (class_exists('BTR_Payment_Email_Manager')) {
            $email_manager = new BTR_Payment_Email_Manager();
            return $email_manager->send_payment_link($email, $payment_link, $participant_data);
        }
        
        // Fallback email base
        $subject = __('Il tuo link per il pagamento - Born to Ride', 'born-to-ride-booking');
        $message = sprintf(
            __('Ciao %s,\n\nEcco il tuo link personale per completare il pagamento:\n%s\n\nIl link scadrà tra 72 ore.\n\nGrazie,\nBorn to Ride Team', 'born-to-ride-booking'),
            $participant_data['name'],
            $payment_link
        );
        
        return wp_mail($email, $subject, $message);
    }
    
    /**
     * Handle deposit payment creation
     * 
     * @param int $order_id
     * @param float $deposit_percentage
     * @return bool|WP_Error
     */
    public function create_deposit_payment($order_id, $deposit_percentage) {
        $order = wc_get_order($order_id);
        if (!$order) {
            return new WP_Error('invalid_order', __('Ordine non valido', 'born-to-ride-booking'));
        }
        
        $total = $order->get_total();
        $deposit_amount = $total * ($deposit_percentage / 100);
        $balance_amount = $total - $deposit_amount;
        
        // Salva informazioni deposito
        update_post_meta($order_id, '_btr_payment_mode', 'deposit_balance');
        update_post_meta($order_id, '_btr_deposit_percentage', $deposit_percentage);
        update_post_meta($order_id, '_btr_deposit_amount', $deposit_amount);
        update_post_meta($order_id, '_btr_balance_amount', $balance_amount);
        update_post_meta($order_id, '_btr_deposit_paid', false);
        update_post_meta($order_id, '_btr_balance_due_date', date('Y-m-d', strtotime('+30 days')));
        
        // Crea record in btr_order_shares per tracciare deposito e saldo
        $customer_email = $order->get_billing_email();
        $customer_name = $order->get_formatted_billing_full_name();
        
        // Record per deposito
        $deposit_share = [
            'order_id' => $order_id,
            'participant_id' => $order->get_customer_id(),
            'participant_name' => $customer_name,
            'participant_email' => $customer_email,
            'amount_assigned' => $deposit_amount,
            'payment_status' => 'pending',
            'notes' => sprintf('Deposito %d%% di %s', $deposit_percentage, wc_price($total))
        ];
        
        $deposit_id = $this->db_manager->create($deposit_share);
        if (is_wp_error($deposit_id)) {
            return $deposit_id;
        }
        
        // Record per saldo
        $balance_share = [
            'order_id' => $order_id,
            'participant_id' => $order->get_customer_id(),
            'participant_name' => $customer_name,
            'participant_email' => $customer_email,
            'amount_assigned' => $balance_amount,
            'payment_status' => 'pending',
            'notes' => sprintf('Saldo di %s', wc_price($balance_amount)),
            'next_reminder_at' => date('Y-m-d H:i:s', strtotime('+25 days'))
        ];
        
        $balance_id = $this->db_manager->create($balance_share);
        if (is_wp_error($balance_id)) {
            return $balance_id;
        }
        
        // Aggiorna totale ordine per il deposito
        $order->set_total($deposit_amount);
        $order->save();
        
        // Aggiungi nota all'ordine
        $order->add_order_note(sprintf(
            __('Modalità caparra attivata. Caparra: %s (%d%%), Saldo: %s', 'born-to-ride-booking'),
            wc_price($deposit_amount),
            $deposit_percentage,
            wc_price($balance_amount)
        ));
        
        btr_debug_log(sprintf('Created deposit payment for order %d: deposit %s, balance %s', 
            $order_id, $deposit_amount, $balance_amount));
        
        return true;
    }
    
    /**
     * Handle payment plan creation
     * Overrides parent method to integrate with btr_order_shares
     * 
     * @param int $plan_id
     * @param int $preventivo_id
     * @param array $plan_data
     */
    public function handle_payment_plan_creation($plan_id, $preventivo_id, $plan_data) {
        // Converti preventivo in ordine se necessario
        $order_id = $this->get_or_create_order_from_preventivo($preventivo_id);
        if (!$order_id) {
            btr_debug_log('Failed to create order from preventivo ' . $preventivo_id);
            return;
        }
        
        switch ($plan_data['plan_type']) {
            case self::PLAN_TYPE_GROUP_SPLIT:
                if (!empty($plan_data['payment_distribution'])) {
                    $this->create_group_payment_shares($order_id, $plan_data['payment_distribution']);
                }
                break;
                
            case self::PLAN_TYPE_DEPOSIT_BALANCE:
                $deposit_percentage = isset($plan_data['deposit_percentage']) ? 
                    intval($plan_data['deposit_percentage']) : 30;
                $this->create_deposit_payment($order_id, $deposit_percentage);
                break;
                
            case self::PLAN_TYPE_FULL:
            default:
                // Pagamento completo standard
                update_post_meta($order_id, '_btr_payment_mode', 'full');
                break;
        }
    }
    
    /**
     * Get or create WooCommerce order from preventivo
     * 
     * @param int $preventivo_id
     * @return int|false Order ID or false
     */
    private function get_or_create_order_from_preventivo($preventivo_id) {
        // Verifica se esiste già un ordine
        $existing_order = get_post_meta($preventivo_id, '_order_id', true);
        if ($existing_order && wc_get_order($existing_order)) {
            return $existing_order;
        }
        
        // Crea nuovo ordine se necessario
        if (class_exists('BTR_Preventivo_To_Order')) {
            $converter = new BTR_Preventivo_To_Order();
            $order_id = $converter->convert_to_order($preventivo_id);
            
            if ($order_id && !is_wp_error($order_id)) {
                update_post_meta($preventivo_id, '_order_id', $order_id);
                return $order_id;
            }
        }
        
        return false;
    }
    
    /**
     * Sync payment status between tables
     * 
     * @param int $payment_id
     * @param string $old_status
     * @param string $new_status
     */
    public function sync_payment_status($payment_id, $old_status, $new_status) {
        // Sincronizza stato tra btr_group_payments e btr_order_shares
        global $wpdb;
        
        // Ottieni dati pagamento da btr_group_payments
        $payment_data = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}btr_group_payments WHERE payment_id = %d",
            $payment_id
        ));
        
        if (!$payment_data) {
            return;
        }
        
        // Trova share corrispondente in btr_order_shares
        $share = $this->db_manager->get_by_email($payment_data->participant_email);
        if (!empty($share)) {
            foreach ($share as $share_record) {
                if ($share_record['order_id'] == $payment_data->order_id) {
                    $this->db_manager->update_payment_status(
                        $share_record['id'],
                        $new_status,
                        $payment_data->transaction_id
                    );
                    break;
                }
            }
        }
    }
    
    /**
     * Process payment reminders
     * Hook per cron job
     */
    public function process_payment_reminders() {
        $pending_reminders = $this->db_manager->get_pending_reminders();
        
        foreach ($pending_reminders as $share) {
            // Invia reminder
            $this->send_payment_reminder($share);
            
            // Incrementa contatore reminder
            $this->db_manager->increment_reminder_count($share['id']);
            
            // Calcola prossimo reminder (3 giorni dopo)
            $next_reminder = date('Y-m-d H:i:s', strtotime('+3 days'));
            $this->db_manager->update($share['id'], [
                'next_reminder_at' => $next_reminder
            ]);
        }
    }
    
    /**
     * Send payment reminder
     * 
     * @param array $share Share data
     * @return bool
     */
    private function send_payment_reminder($share) {
        $subject = __('Promemoria pagamento - Born to Ride', 'born-to-ride-booking');
        $message = sprintf(
            __('Ciao %s,\n\nTi ricordiamo che hai un pagamento in sospeso di %s.\n\nPuoi completare il pagamento al seguente link:\n%s\n\nGrazie,\nBorn to Ride Team', 'born-to-ride-booking'),
            $share['participant_name'],
            wc_price($share['amount_assigned']),
            $share['payment_link']
        );
        
        return wp_mail($share['participant_email'], $subject, $message);
    }
    
    /**
     * Get payment statistics for an order
     * 
     * @param int $order_id
     * @return array
     */
    public function get_order_payment_statistics($order_id) {
        return $this->db_manager->get_order_statistics($order_id);
    }
    
    /**
     * Check if all shares are paid for an order
     * 
     * @param int $order_id
     * @return bool
     */
    public function are_all_shares_paid($order_id) {
        $stats = $this->get_order_payment_statistics($order_id);
        return isset($stats['pending_count']) && $stats['pending_count'] === 0;
    }
}